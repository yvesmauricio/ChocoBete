<template>
  <div class="shell" :class="{ 'shell--bete': perfilInfo?.tipo === 'caderneta' || perfilInfo?.tipo === 'consulta' }">

    <!-- ══ CONFIGURAÇÃO DO APARELHO (1ª abertura, ou editar nome/tipo) ═══
         Cada aparelho diz quem é (Vendedor ou Admin) e daí em diante só abre o módulo dele. -->
    <ConfigurarAparelho
      v-if="aparelhoCarregado && (!aparelho || editandoAparelho)"
      :edicao="!!aparelho"
      @pronto="aoConfigurarAparelho"
      @cancelar="editandoAparelho = false"
    />

    <!-- ══ MODO ADMIN ═══════════════════════════════════════════ -->
    <template v-if="perfilInfo?.tipo === 'admin'">
      <AppHeader />

      <main class="main">
        <TabReceitas     v-if="abasVisitadas.receitas" v-show="s.tab === 'receitas'" />
        <TabProducao     v-if="abasVisitadas.producao" v-show="s.tab === 'producao'" />
        <TabPainel       v-if="abasVisitadas.painel" v-show="s.tab === 'painel'" />
        <TabInsumos      v-if="abasVisitadas.insumos" v-show="s.tab === 'insumos'" />
        <TabInteligencia v-if="abasVisitadas.inteligencia" v-show="s.tab === 'inteligencia'" />
        <TabFinanceiro   v-if="abasVisitadas.financeiro" v-show="s.tab === 'financeiro'" />
        <TabCozinha      v-if="abasVisitadas.cozinha" v-show="s.tab === 'cozinha'" />
        <TabBriefing     v-if="abasVisitadas.briefing" v-show="s.tab === 'briefing'" />
        <TabAjustes      v-if="abasVisitadas.ajustes" v-show="s.tab === 'ajustes'" />
        <TabEtiquetas    v-if="abasVisitadas.etiquetas" v-show="s.tab === 'etiquetas'" />
        <TabCardapio     v-if="abasVisitadas.cardapio" v-show="s.tab === 'cardapio'" />
      </main>

      <AppNav :modulos="perfilInfo.modulos" />

      <!-- FAB contextual — canto inferior direito, acima da nav -->
      <Transition name="fab-pop">
        <button
          v-if="fabConfig"
          class="fab" :class="`fab--${s.tab}`"
          :title="fabConfig.label"
          @click="fabConfig.action()"
        >
          <i :class="fabConfig.icon"></i>
        </button>
      </Transition>

      <!-- O cronômetro de produção aparece só no card do lote em execução (aba Produção); não há mais balão flutuante. -->

      <!-- O indicador de sync do perfil Admin agora é um botão no próprio
           AppHeader (mesmo tamanho do botão "trocar perfil"), não mais
           uma bolinha discreta — ver AppHeader.vue. -->
    </template>

    <!-- ══ MODO BETE (Caderneta) ═══════════════════════════════ -->
    <template v-if="perfilInfo?.tipo === 'caderneta'">
      <main class="main main--bete">
        <!-- Aparelho Vendedor: o botão do cabeçalho abre "Este aparelho", não troca de perfil. -->
        <TabCaderneta @trocar-perfil="mostrarAparelho = true" />
      </main>

      <!-- O indicador de sync da Bete agora é um botão no cabeçalho do Início
           (TabCaderneta.vue), não mais uma bolinha flutuante. -->

    </template>

    <!-- ══ VENDAS SOMENTE CONSULTA (aparelho Admin) ═════════════ -->
    <template v-if="perfilInfo?.tipo === 'consulta'">
      <main class="main main--bete">
        <TabVendasConsulta @voltar="voltarAoAdmin" />
      </main>
    </template>

    <AparelhoSheet
      v-if="mostrarAparelho"
      @fechar="mostrarAparelho = false"
      @abrir-admin="abrirAdminTemporario"
      @editar-aparelho="editarAparelho"
    />

    <!-- ─── Confirmação Global (compartilhada) ────────────────── -->
    <ConfirmDialog />

    <!-- Aviso de nova versão do app (PWA) -->
    <AtualizacaoBanner />

    <!-- Toast global -->
    <Transition name="fade" mode="out-in">
      <div
        v-if="s.toast"
        :key="s.toast.id"
        class="toast"
        :class="[`toast-${s.toast.tipo}`, { 'toast--sutil': perfilInfo?.tipo === 'caderneta' }]"
      >
        {{ s.toast.msg }}
      </div>
    </Transition>

    <!-- Loader global -->
    <Transition name="fade">
      <div v-if="s.loading" class="loader-overlay">
        <div class="spinner"></div>
        <p>Carregando dados…</p>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { onMounted, onUnmounted, reactive, computed, ref, provide, watch } from 'vue'
import { useStore } from './store.js'
import { useAndroidBackGuard } from './composables/useAndroidBackGuard.js'
import { tentarReconectarSilenciosamente, iniciarRenovacaoPorToque } from './services/googleDriveBackup.js'
import { iniciarMonitorPedidosSite } from './services/pedidosSite.js'
import AppHeader      from './components/AppHeader.vue'
import AppNav         from './components/AppNav.vue'
import ConfirmDialog  from './components/ConfirmDialog.vue'
import AtualizacaoBanner from './components/AtualizacaoBanner.vue'
import ConfigurarAparelho from './views/ConfigurarAparelho.vue'
import AparelhoSheet  from './components/AparelhoSheet.vue'
import { aparelho, aparelhoCarregado, carregarAparelho } from './store/aparelho.js'
import {
  TabReceitas, TabProducao, TabPainel, TabInsumos, TabInteligencia, TabFinanceiro,
  TabCozinha, TabAjustes, TabBriefing, TabEtiquetas, TabCardapio, TabCaderneta, TabVendasConsulta
} from './views/abasAsync.js'

const s = useStore()

// ── FAB contextual ──────────────────────────────────────────
const fabConfig  = ref(null)
const fabOwnerId = ref(null)
provide('registerFab', (config, ownerId) => {
  fabOwnerId.value = ownerId
  fabConfig.value  = config
})
provide('unregisterFab', (ownerId) => {
  if (fabOwnerId.value === ownerId) {
    fabConfig.value  = null
    fabOwnerId.value = null
  }
})

// ── Perfil ─────────────────────────────────────────────────
const perfil = ref(null) // null = ainda não entrou (carregando / aparelho sem configuração)

// Resolve o perfil atual ('ym' = Admin, 'bete' = Vendas) para o "tipo" de
// casca que a tela deve montar.
// Aparelho Vendedor só abre a Caderneta. A única exceção é o "modo Admin temporário"
// (liberado pelo PIN, para restaurar dados etc.), que some ao sair ou reabrir o app.
const mostrarAparelho = ref(false)
const editandoAparelho = ref(false)
const modoAdminTemporario = ref(false)

const perfilInfo = computed(() => {
  if (!aparelho.value) return null
  const vendedor = aparelho.value.papel === 'vendedor'
  if (vendedor && !modoAdminTemporario.value && perfil.value !== 'bete') return null
  if (perfil.value === 'ym') return { tipo: 'admin', modulos: s.perfis.ym.modulos }
  // 'bete' = Vendas: no aparelho do vendedor é a Caderneta completa; no Admin, só consulta.
  if (perfil.value === 'bete') return { tipo: vendedor ? 'caderneta' : 'consulta' }
  return null
})

// ── Abas sob demanda ───────────────────────────────────────
// Cada aba só é montada (e seu código só é baixado) na 1ª vez que é aberta.
// Depois disso continua montada com v-show, como antes — o estado dela
// (filtros, formulários, rascunhos) não se perde ao trocar de aba.
// Ao sair do perfil (volta pra seleção), zera: o próximo perfil começa leve.
const abasVisitadas = reactive({})
watch([() => s.tab, perfilInfo], ([tab, info]) => {
  if (info?.tipo !== 'admin') {
    for (const k of Object.keys(abasVisitadas)) delete abasVisitadas[k]
    return
  }
  abasVisitadas[tab] = true
}, { immediate: true })

async function onSelecionarPerfil(p) {
  // Para a Bete: antes de abrir, traz o que outro aparelho tiver salvo no
  // Drive (se não há alterações pendentes aqui). Antes ela só ENVIAVA ao
  // entrar — um app que ficou aberto por horas mandava a foto velha por
  // cima do que o outro aparelho tinha feito. O limite de 4 s evita travar
  // a entrada com internet ruim.
  if (p === 'bete' && aparelho.value?.papel === 'vendedor' && s.googleDriveConfigured) {
    await Promise.race([s.iniciarSync(), new Promise(resolve => setTimeout(resolve, 4000))])
    perfil.value = p
    if (s.hasLocalChanges) s.syncImediato()
    return
  }
  perfil.value = p
}

// Aparelho Admin: o app já abre direto no Admin. As vendas (somente consulta)
// são um atalho no cabeçalho; "voltar" traz de volta ao Admin.
function abrirVendasConsulta() { perfil.value = 'bete' }
function voltarAoAdmin() { perfil.value = 'ym' }

function voltarParaVendas() {
  modoAdminTemporario.value = false
  perfil.value = 'bete'
  if (s.hasLocalChanges) s.syncImediato()
}

function abrirAdminTemporario() {
  mostrarAparelho.value = false
  modoAdminTemporario.value = true
  perfil.value = 'ym'
  s.setTab('ajustes')
}

function editarAparelho() {
  mostrarAparelho.value = false
  editandoAparelho.value = true
}

// Depois de configurar (ou mudar) o aparelho: entra direto no que ele vai usar.
async function aoConfigurarAparelho() {
  editandoAparelho.value = false
  modoAdminTemporario.value = false
  await entrarConformeAparelho()
}

async function entrarConformeAparelho() {
  if (aparelho.value?.papel === 'vendedor') {
    await onSelecionarPerfil('bete')
  } else if (aparelho.value?.papel === 'admin') {
    perfil.value = 'ym'
  }
}

// Primeira configuração do aparelho: entra no módulo assim que `aparelho` é gravado.
// Não dá para depender só do evento `pronto` do ConfigurarAparelho: `salvarAparelho()`
// preenche `aparelho`, o `v-if` da tela fecha e desmonta o componente ANTES de o
// `emit('pronto')` rodar — e o Vue ignora emit de componente já desmontado. Resultado:
// `perfil` ficava null e a tela em branco até recarregar (onMounted chamava
// entrarConformeAparelho). Na edição (`editandoAparelho`) a tela continua montada e o
// `pronto` chega normalmente, então não entra aqui.
watch(aparelho, (novo) => {
  if (novo && perfil.value === null && !editandoAparelho.value) entrarConformeAparelho()
})

// Atalho do cabeçalho do Admin (AppHeader). Aparelho Admin: abre as vendas em
// somente consulta. Vendedor no modo Admin temporário: sai e volta para as vendas.
const atalhoHeader = computed(() => {
  if (!aparelho.value || perfil.value !== 'ym') return null
  if (aparelho.value.papel === 'vendedor') {
    return { label: 'Sair do Admin', icone: 'fa-arrow-right-from-bracket', titulo: 'Sair do modo Admin e voltar para as vendas', acao: voltarParaVendas }
  }
  return {
    label: s.perfis.bete.nome || 'Vendas',
    icone: 'fa-book-open',
    titulo: 'Ver lojas, clientes e cobranças (somente consulta)',
    acao: abrirVendasConsulta
  }
})
provide('atalhoHeader', atalhoHeader)

// ── Sync ─────────────────────────────────────────────────
// Nota: para a Bete, o sync já dispara em cada alteração real de dados
// (ver s.syncImediato() nas funções de salvar/receber/quitar/excluir em
// TabCaderneta.vue). Não sincronizamos aqui de novo ao voltar o foco —
// isso disparava um sync extra a cada troca de tela ou volta do WhatsApp,
// mesmo sem nada ter mudado.
let escondidoDesde = 0
const REVERIFICAR_APOS_MS = 5 * 60_000
const onVisibilityChange = async () => {
  if (document.visibilityState === 'hidden') {
    escondidoDesde = Date.now()
    s.salvarBackupLocalAgora() // grava já a cópia na pasta local, sem esperar o intervalo
    return
  }
  if (document.visibilityState === 'visible') {
    if (perfilInfo.value?.tipo === 'admin') {
      await s.iniciarSync()
    } else if (perfilInfo.value?.tipo === 'consulta') {
      // A própria tela de consulta atualiza ao voltar (TabVendasConsulta).
    } else if (perfilInfo.value?.tipo === 'caderneta' && escondidoDesde && Date.now() - escondidoDesde > REVERIFICAR_APOS_MS) {
      // Bete: só reconfere o Drive se ficou um tempo fora do app (voltar do
      // WhatsApp em segundos não precisa) — evita enviar por cima de algo novo.
      await s.iniciarSync()
    }
  }
}

// Voltou a internet: envia o que ficou pendente enquanto estava offline.
const onOnline = () => { if (s.hasLocalChanges) s.syncImediato() }

// Impede que o botão/gesto "Voltar" do Android feche o app de primeira —
// o primeiro toque navega para a aba inicial; só sai do app a partir dela.
useAndroidBackGuard({
  getTab: () => s.tab,
  setTab: (t) => s.setTab(t),
  tabInicial: 'painel',
})

// Pedidos feitos no site: o app confere o servidor enquanto está aberto. Sem a chave do
// servidor em Ajustes isto não faz nada. Pedido novo vira aviso + vai pro Drive (outros aparelhos).
let pararMonitorPedidosSite = null
// Acesso ao Google Drive: renova no toque quando vence e sincroniza o que ficou esperando.
let pararRenovacaoDrive = null
function aoTokenDriveRenovado() { s.agendarSync?.(); s.syncImediato?.() }
function aoChegarPedidosDoSite(qtd, atualizados = 0) {
  if (qtd > 0) s.notify?.(qtd === 1 ? 'Novo pedido do site!' : `${qtd} novos pedidos do site!`, 'success')
  window.dispatchEvent(new CustomEvent('pedidos-site:novos'))
  if (s.googleDriveConfigured) { s.agendarSync?.(); s.syncImediato?.() }
}

onMounted(async () => {
  await s.init()
  await carregarAparelho()
  await entrarConformeAparelho()
  tentarReconectarSilenciosamente()
  document.addEventListener('visibilitychange', onVisibilityChange)
  window.addEventListener('online', onOnline)
  pararMonitorPedidosSite = iniciarMonitorPedidosSite({ aoChegar: aoChegarPedidosDoSite, intervaloMs: 15000 })
  pararRenovacaoDrive = iniciarRenovacaoPorToque()
  window.addEventListener('google-drive:token-renovado', aoTokenDriveRenovado)
})

onUnmounted(() => {
  window.removeEventListener('mousemove', onMouseDragMove)
  window.removeEventListener('mouseup', onMouseDragEnd)
  document.removeEventListener('visibilitychange', onVisibilityChange)
  window.removeEventListener('online', onOnline)
  pararMonitorPedidosSite?.()
  pararRenovacaoDrive?.()
  window.removeEventListener('google-drive:token-renovado', aoTokenDriveRenovado)
})
</script>

<style scoped>
/* ── Posições fixas dos elementos flutuantes (sem colisão) ─────
   
   Zona superior (topo, fora do conteúdo):
     Toast           → topo-centro, z mais alto, some sozinho
     Sync            → dentro do AppHeader (não flutua)

   Zona inferior (acima da nav = bottom: 64px + gap):
     FAB             → canto direito  (bottom: 80px, right: 16px)
     Timer           → canto esquerdo (bottom: 80px, left: 16px)  ← posição inicial
     
   Não sobrepõem porque estão em lados opostos.
   O timer é arrastável — se o usuário mover para a direita pode colidir
   com o FAB, mas só se arrastar intencionalmente.
──────────────────────────────────────────────────────────────── */

/* ── FAB ─────────────────────────────────────────────────── */
.fab {
  position: fixed;
  bottom: 80px;
  right: 16px;
  width: 52px; height: 52px;
  border-radius: 50%;
  background: var(--brown-dark);
  color: #fff;
  border: none;
  font-size: 1.3rem;
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 3px 12px rgba(61,31,7,.3);
  z-index: calc(var(--z-header) + 5);
  cursor: pointer;
  transition: transform .15s, box-shadow .15s;
}
.fab:active { transform: scale(.91); box-shadow: 0 2px 8px rgba(61,31,7,.2); }
.fab-pop-enter-active { animation: fab-in .22s cubic-bezier(.34,1.56,.64,1); }
.fab-pop-leave-active { animation: fab-in .15s ease-in reverse; }
@keyframes fab-in {
  from { opacity:0; transform: scale(.4); }
  to   { opacity:1; transform: scale(1); }
}

</style>