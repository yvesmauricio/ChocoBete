<template>
  <div class="tab-financeiro">

    <!-- ── Cabeçalho ───────────────────────────────────── -->
    <div class="tab-hdr">
      <div class="tab-hdr-top">
        <h2 class="tab-title"><i class="fas fa-money-check-dollar"></i> Financeiro</h2>
        <!-- ── Seletor de grupo (estilo seletor, igual ao Painel) ── -->
        <div ref="grupoStripEl" class="seg-control">
          <button v-for="g in grupos" :key="g.id" class="seg-btn"
            :ref="el => setGrupoRef(el, g.id)"
            :class="{ active: grupoAtivo === g.id }"
            @click="grupoAtivo = g.id">
            {{ g.label }}
          </button>
        </div>
      </div>

      <!-- ── Navegação de abas ────────────────────────── -->
      <div ref="abaStripEl" class="aba-nav">
        <button v-for="aba in abasVisiveis" :key="aba.id" class="aba-btn"
          :ref="el => setAbaRef(el, aba.id)"
          :class="{ active: abaAtiva === aba.id }"
          :data-id="aba.id"
          @click="abaAtiva = aba.id">
          <i :class="aba.icon"></i> {{ aba.label }}
        </button>
      </div>
    </div>

    <!-- ═══ ABA: IMPORTAR ═══ -->
    <template v-if="abaAtiva === 'importar'">
      <div class="relatorio-wrap im-pagina">

        <header class="im-cab">
          <h3 class="im-titulo">Importar extrato</h3>
          <p class="im-desc">Traga os lançamentos do seu banco para o app enviando o arquivo do extrato.</p>
        </header>

        <div v-if="!temAlgumBancoConfigurado" class="im-card im-vazio">
          <div class="im-vazio-icone"><i class="fas fa-building-columns"></i></div>
          <strong>Nenhuma conta cadastrada</strong>
          <span>Cadastre uma conta bancária em Ajustes › Financeiro para poder importar extratos.</span>
        </div>

        <template v-else>
          <!-- Passo 1: banco (só aparece quando há mais de um) -->
          <section v-if="bancosImportacaoDisponiveis.length > 1" class="im-bloco">
            <div class="im-passo-cab"><span class="im-passo">1</span><h4>Escolha o banco</h4></div>
            <div class="im-bancos" role="radiogroup" aria-label="Banco do extrato">
              <button v-if="temContasPagbank" class="im-banco" :class="{ active: bancoImport === 'pagbank' }" role="radio" :aria-checked="bancoImport === 'pagbank'" @click="bancoImport = 'pagbank'">
                <i class="fas fa-file-csv"></i><strong>PagBank</strong><span>arquivo CSV</span>
              </button>
              <button v-if="temContasItau" class="im-banco" :class="{ active: bancoImport === 'itau' }" role="radio" :aria-checked="bancoImport === 'itau'" @click="bancoImport = 'itau'">
                <i class="fas fa-file-pdf"></i><strong>Itaú</strong><span>arquivo PDF</span>
              </button>
              <button v-if="temContasBb" class="im-banco" :class="{ active: bancoImport === 'bb' }" role="radio" :aria-checked="bancoImport === 'bb'" @click="bancoImport = 'bb'">
                <i class="fas fa-file-csv"></i><strong>BB</strong><span>arquivo CSV</span>
              </button>
            </div>
          </section>

          <!-- Passo 2: envio do arquivo (os importadores são componentes próprios, não mudam) -->
          <section class="im-bloco">
            <div class="im-passo-cab">
              <span v-if="bancosImportacaoDisponiveis.length > 1" class="im-passo">2</span>
              <h4>{{ bancoImport === 'itau' ? 'Envie o PDF do Itaú' : bancoImport === 'bb' ? 'Envie o CSV do Banco do Brasil' : 'Envie o CSV do PagBank' }}</h4>
            </div>
            <div class="im-card im-card--painel">
              <div class="importador-panel">
                <ImportadorExtrato v-if="bancoImport === 'pagbank'" @editar-lancamento="abrirModalEdicao" />
                <ImportadorItau v-else-if="bancoImport === 'itau'" />
                <ImportadorBancoBrasil v-else-if="bancoImport === 'bb'" />
              </div>
            </div>
          </section>
        </template>

        <!-- Gerenciar / excluir extratos: separado e em vermelho, por ser irreversível -->
        <section v-if="s.financeiro.length" class="im-bloco">
          <div class="im-card im-card--risco">
            <button class="im-admin-toggle" :aria-expanded="mostrarExcluirBanco" @click="mostrarExcluirBanco = !mostrarExcluirBanco">
              <span class="im-admin-icone"><i class="fas fa-trash-can"></i></span>
              <span class="im-admin-txt">
                <strong>Excluir extratos importados</strong>
                <small>{{ s.financeiro.length }} {{ s.financeiro.length === 1 ? 'lançamento guardado' : 'lançamentos guardados' }}</small>
              </span>
              <i class="fas im-admin-seta" :class="mostrarExcluirBanco ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
            </button>
            <Transition name="fade-slide">
              <div v-if="mostrarExcluirBanco" class="im-excluir">
                <p class="im-excluir-aviso"><i class="fas fa-triangle-exclamation"></i> Apagar é permanente e não dá para desfazer. Antes de confirmar, o app pergunta de novo.</p>
                <button v-for="b in bancosComLancamentos" :key="b.id" class="im-excluir-btn" @click="handleExcluirPorBanco(b.id)">
                  <span class="im-excluir-nome">{{ b.label }}</span>
                  <span class="im-excluir-qtd">{{ b.count }} {{ b.count === 1 ? 'lançamento' : 'lançamentos' }}</span>
                  <i class="fas fa-chevron-right"></i>
                </button>
                <button class="im-excluir-btn im-excluir-btn--todos" @click="handleExcluirPorBanco('todos')">
                  <span class="im-excluir-nome">Excluir tudo</span>
                  <span class="im-excluir-qtd">{{ s.financeiro.length }} {{ s.financeiro.length === 1 ? 'lançamento' : 'lançamentos' }}</span>
                  <i class="fas fa-chevron-right"></i>
                </button>
              </div>
            </Transition>
          </div>
        </section>
      </div>
    </template>

    <template v-else-if="abaAtiva === 'lancamentos'">

      <!-- ── Bloco sticky: resumo + filtros ── -->
      <div class="lancamentos-sticky">

        <!-- Resumo -->
        <div class="resumo-modern" v-if="lancamentosFiltrados.length">
          <div class="rm-item">
            <span class="rm-lbl">Entradas</span>
            <span class="rm-val c-green">{{ R$(totalEntradas) }}</span>
          </div>
          <div class="rm-sep"></div>
          <div class="rm-item">
            <span class="rm-lbl">Saídas</span>
            <span class="rm-val c-red">{{ R$(totalSaidas) }}</span>
          </div>
          <div class="rm-sep"></div>
          <div class="rm-item">
            <span class="rm-lbl">Saldo</span>
            <span class="rm-val" :class="saldoFiltrado >= 0 ? 'c-green' : 'c-red'">{{ R$(saldoFiltrado) }}</span>
          </div>
        </div>

        <!-- Barra de filtros compacta: uma única linha de chips + popover contextual -->
        <div class="filtros-bar">
          <div class="fbar-row">
            <button class="fbar-search-btn" :class="{ active: popoverAtivo === 'busca' }" aria-label="Buscar por descrição" @click="togglePopover('busca')">
              <i class="fas fa-search"></i>
            </button>
            <div class="fbar-scroll">
              <button v-if="mesesDisponiveis.length" class="fbar-chip" :class="{ active: filtroMes, open: popoverAtivo === 'periodo' }" @click="togglePopover('periodo')">
                {{ filtroMes || 'Período' }} <i class="fas fa-chevron-down fbar-chip-caret"></i>
              </button>
              <button v-if="filtrosBanco.length > 2" class="fbar-chip" :class="{ active: filtroBanco, open: popoverAtivo === 'banco' }" @click="togglePopover('banco')">
                {{ bancoAtivoLabel }} <i class="fas fa-chevron-down fbar-chip-caret"></i>
              </button>
              <button class="fbar-chip" :class="{ active: filtroNatureza, open: popoverAtivo === 'tipo' }" @click="togglePopover('tipo')">
                {{ tipoAtivoLabel }} <i class="fas fa-chevron-down fbar-chip-caret"></i>
              </button>
              <button class="fbar-chip" :class="{ active: filtroCategoria, open: popoverAtivo === 'categoria' }" @click="togglePopover('categoria')">
                {{ filtroCategoria || 'Categoria' }} <i class="fas fa-chevron-down fbar-chip-caret"></i>
              </button>
            </div>
            <button v-if="filtrosAtivosCount" class="fbar-limpar" aria-label="Limpar filtros" @click="limparFiltros">
              <span class="fbar-limpar-badge">{{ filtrosAtivosCount }}</span> <i class="fas fa-xmark"></i>
            </button>
          </div>

          <!-- Popover: Buscar -->
          <Transition name="fade-slide">
            <div v-if="popoverAtivo === 'busca'" class="filtro-popover">
              <div class="fbusca-wrap">
                <i class="fas fa-search fbusca-icon"></i>
                <input v-model.trim="buscaDescricao" class="fbusca-input" type="search" placeholder="Buscar por descrição..." autofocus />
                <button v-if="buscaDescricao" class="fbusca-clear" aria-label="Limpar busca" @click="buscaDescricao = ''"><i class="fas fa-xmark"></i></button>
              </div>
            </div>
          </Transition>

          <!-- Popover: Período -->
          <Transition name="fade-slide">
            <div v-if="popoverAtivo === 'periodo'" class="filtro-popover">
              <div class="periodo-inline">
                <button class="pnav-mini-btn" :disabled="!temMesMaisNovo" @click="irParaMesMaisNovo"><i class="fas fa-chevron-left"></i></button>
                <div class="pnav-mini-centro">
                  <select v-model="filtroMes"><option value="">Todos</option><option v-for="m in mesesDisponiveis" :key="m" :value="m">{{ m }}</option></select>
                  <span>{{ filtroMes || 'Todos os períodos' }}</span>
                </div>
                <button class="pnav-mini-btn" :disabled="!temMesMaisAntigo" @click="irParaMesMaisAntigo"><i class="fas fa-chevron-right"></i></button>
              </div>
            </div>
          </Transition>

          <!-- Popover: Banco -->
          <Transition name="fade-slide">
            <div v-if="popoverAtivo === 'banco'" class="filtro-popover">
              <div class="fchips">
                <button v-for="b in filtrosBanco" :key="b.id" class="fchip" :class="{ active: filtroBanco === b.id }"
                  @click="filtroBanco = b.id; popoverAtivo = ''">{{ b.label }}</button>
              </div>
            </div>
          </Transition>

          <!-- Popover: Tipo de gasto -->
          <Transition name="fade-slide">
            <div v-if="popoverAtivo === 'tipo'" class="filtro-popover">
              <div class="fchips">
                <button class="fchip" :class="{ active: !filtroNatureza }" @click="filtroNatureza = ''; popoverAtivo = ''">Todos</button>
                <button class="fchip" :class="{ active: filtroNatureza === 'entrada' }" @click="selecionarNatureza('entrada'); popoverAtivo = ''">Receitas</button>
                <button class="fchip" :class="{ active: filtroNatureza === 'operacional' }" @click="selecionarNatureza('operacional'); popoverAtivo = ''">Custos</button>
                <button class="fchip" :class="{ active: filtroNatureza === 'pessoal' }" @click="selecionarNatureza('pessoal'); popoverAtivo = ''">Pessoal</button>
              </div>
            </div>
          </Transition>

          <!-- Popover: Categoria -->
          <Transition name="fade-slide">
            <div v-if="popoverAtivo === 'categoria'" class="filtro-popover filtro-popover-scroll">
              <div class="cat-list">
                <button class="cat-list-item" :class="{ active: !filtroCategoria }"
                  @click="selecionarCategoria('')">
                  <i class="fas fa-layer-group cat-list-icon"></i>
                  <span>Todas as categorias</span>
                  <i v-if="!filtroCategoria" class="fas fa-check cat-list-check"></i>
                </button>
                <template v-for="grupo in gruposCategoriasFiltro" :key="grupo.nome">
                  <div class="cat-list-grupo">{{ grupo.nome }}</div>
                  <button v-for="cat in grupo.categorias" :key="cat.nome"
                    class="cat-list-item" :class="{ active: filtroCategoria === cat.nome }"
                    @click="selecionarCategoria(cat.nome)">
                    <i class="fas cat-list-icon" :class="cat.icon"></i>
                    <span>{{ cat.nome }}</span>
                    <i v-if="filtroCategoria === cat.nome" class="fas fa-check cat-list-check"></i>
                  </button>
                </template>
              </div>
            </div>
          </Transition>
        </div><!-- fim .filtros-bar -->

        <!-- Contagem de resultados (só quando algum filtro ativo) -->
        <div v-if="filtrosAtivosCount" class="fm-status-bar">
          <span class="fm-count">{{ lancamentosFiltrados.length }} {{ lancamentosFiltrados.length === 1 ? 'lançamento encontrado' : 'lançamentos encontrados' }}</span>
        </div>
      </div><!-- fim .lancamentos-sticky -->

      <!-- Dica de seleção (só quando NÃO está no modo seleção) -->
      <div v-if="!modoSelecao && lancamentosFiltrados.length" class="selecao-dica">
        <i class="fas fa-hand-pointer"></i> Segure um item para selecionar vários
      </div>

      <!-- Barra de seleção em lote (quando ativa) -->
      <div v-if="modoSelecao" class="selecao-bar">
        <button class="sel-all-btn" @click="toggleSelecionarTodos">
          <i :class="todosSelecionados ? 'fas fa-square-check' : 'far fa-square'"></i>
          {{ todosSelecionados ? 'Desmarcar' : `Todos (${lancamentosFiltrados.length})` }}
        </button>
        <span v-if="selecionados.size" class="sel-count">{{ selecionados.size }} sel.</span>
        <button class="sel-fechar-btn" aria-label="Sair da seleção" @click="toggleSelecao"><i class="fas fa-xmark"></i></button>
      </div>

      <!-- Transferências internas: linha discreta, não ocupa espaço grande -->
      <button v-if="transInternasCount && !filtroCategoria"
        class="trans-interna-hint"
        @click="selecionarCategoria('Transferência Interna')">
        <i class="fas fa-arrow-right-arrow-left"></i>
        {{ transInternasCount }} {{ transInternasCount === 1 ? 'transferência interna oculta' : 'transferências internas ocultas' }} · toque para ver
      </button>

      <!-- Vazio -->
      <div v-if="!lancamentosFiltrados.length" class="app-empty">
        <i class="fas fa-inbox"></i>
        <h3>Nenhum lançamento</h3>
        <p>Importe um extrato ou ajuste os filtros.</p>
        <button v-if="temAlgumBancoConfigurado" class="btn btn-primary btn-sm mt-12" @click="abaAtiva = 'importar'">
          <i class="fas fa-file-import"></i> Importar extrato
        </button>
      </div>

      <!-- Lista simplificada -->
      <div v-else class="lancamentos-list">
        <!-- Cabeçalho de colunas (só aparece no layout de desktop) -->
        <div class="tbl-head tbl-head--fin" :class="{ 'tbl-head--sel': modoSelecao }" aria-hidden="true">
          <span>Descrição</span><span>Categoria</span><span>Data</span><span>Conta</span><span class="th-right">Valor</span>
        </div>
        <FinanceListRow v-for="item in lancamentosFiltrados" :key="item.id"
          :variant="item.natureza"
          :selected="selecionados.has(item.id)"
          :muted="item.natureza === 'interna'"
          class="lancamento-row"
          :class="{
            'row-interna': item.natureza === 'interna',
            'row-operacional': item.natureza === 'operacional',
            'row-pessoal': item.natureza === 'pessoal',
            'row-entrada': item.natureza === 'entrada',
            'row-selected': selecionados.has(item.id),
            'modo-selecao': modoSelecao
          }"
          @click="modoSelecao ? toggleItem(item.id) : abrirModalEdicao(item)"
          @touchstart.passive="iniciarLongPress(item)"
          @touchend.passive="cancelarLongPress"
          @touchmove.passive="cancelarLongPress">

          <!-- Checkbox modo seleção -->
          <div v-if="modoSelecao" class="row-check">
            <i :class="selecionados.has(item.id) ? 'fas fa-square-check' : 'far fa-square'"></i>
          </div>

          <div class="row-left">
            <div class="row-title">{{ capitalizarDescricao(item.descricao) }}</div>
            <div class="row-subtitle">
              <span class="fl-data">{{ formatarData(item.data) }}</span>
              <span class="badge">{{ item.categoria }}</span>
              <span class="fl-banco" :title="item.banco === 'itau' ? 'Itaú' : item.banco === 'bb' ? 'Banco do Brasil' : 'PagBank'"><span class="fl-dot">·</span> <span class="fl-banco-nome">{{ item.banco === 'itau' ? 'Itaú' : item.banco === 'bb' ? 'BB' : 'PagBank' }}</span><span class="fl-banco-sigla">{{ item.banco === 'itau' ? 'IT' : item.banco === 'bb' ? 'BB' : 'PB' }}</span></span>
            </div>
          </div>
          <div class="row-right" :class="item.valor >= 0 ? 'green' : 'red'">
            {{ item.valor >= 0 ? '+' : '−' }}{{ R$(Math.abs(item.valor)) }}
          </div>
        </FinanceListRow>
      </div>
    </template>

    <!-- ═══ ABA: MENSAL ═══ -->
    <template v-else-if="abaAtiva === 'mensal'">
      <div class="relatorio-wrap mn-pagina">

        <!-- ── Período: ano + mês, com campos visíveis e setas grandes ── -->
        <div class="mn-periodo">
          <div class="mn-campo mn-campo--ano">
            <label class="mn-label" for="mn-ano">Ano</label>
            <select id="mn-ano" v-model="anoFiltroMensal" class="mn-select">
              <option v-for="a in anosDisponiveis" :key="a" :value="a">{{ a }}</option>
            </select>
          </div>
          <div v-if="mesesParaFiltroMensal.length" class="mn-campo mn-campo--mes">
            <label class="mn-label" for="mn-mes">Mês</label>
            <div class="mn-mes">
              <button class="mn-seta" :disabled="idxMesMensal === 0" aria-label="Mês mais recente" @click="irParaMesNovoMensal"><i class="fas fa-chevron-left"></i></button>
              <select id="mn-mes" v-model="mesFiltroMensal" class="mn-select">
                <option value="">Ano todo</option>
                <option v-for="m in mesesParaFiltroMensal" :key="m" :value="m">{{ m }}</option>
              </select>
              <button class="mn-seta" :disabled="idxMesMensal === mesesParaFiltroMensal.length - 1" aria-label="Mês mais antigo" @click="irParaMesAntigoMensal"><i class="fas fa-chevron-right"></i></button>
            </div>
          </div>
        </div>

        <!-- ── Resumo por banco ── -->
        <section class="mn-bloco">
          <header class="mn-bloco-cab">
            <h4 class="mn-bloco-titulo">Por banco</h4>
            <span class="mn-bloco-sub">{{ mesFiltroMensal || ('Ano ' + anoFiltroMensal) }}</span>
          </header>
          <div class="mn-card">
            <div v-if="temContasPagbank || resumoBancoPagbank.receitas || resumoBancoPagbank.saidas" class="mn-banco">
              <div class="mn-banco-topo">
                <div class="mn-tile mn-tile--pagbank"><i class="fas fa-mobile-screen"></i></div>
                <div class="mn-banco-nome">PagBank</div>
                <div class="mn-banco-saldo">
                  <span class="mn-mini-lbl">Saldo</span>
                  <strong :class="resumoBancoPagbank.saldo >= 0 ? 'c-green' : 'c-red'">{{ R$(resumoBancoPagbank.saldo) }}</strong>
                </div>
              </div>
              <div class="mn-banco-det">
                <div><span>Receitas PIX</span><strong class="c-green">{{ R$(resumoBancoPagbank.receitas) }}</strong></div>
                <div><span>Saídas</span><strong class="c-red">{{ R$(resumoBancoPagbank.saidas) }}</strong></div>
              </div>
            </div>
            <div v-if="temContasItau || resumoBancoItau.receitas || resumoBancoItau.saidas" class="mn-banco">
              <div class="mn-banco-topo">
                <div class="mn-tile mn-tile--itau"><i class="fas fa-landmark"></i></div>
                <div class="mn-banco-nome">Itaú</div>
                <div class="mn-banco-saldo">
                  <span class="mn-mini-lbl">Saldo</span>
                  <strong :class="resumoBancoItau.saldo >= 0 ? 'c-green' : 'c-red'">{{ R$(resumoBancoItau.saldo) }}</strong>
                </div>
              </div>
              <div class="mn-banco-det">
                <div><span>Receitas PIX</span><strong class="c-green">{{ R$(resumoBancoItau.receitas) }}</strong></div>
                <div><span>Saídas</span><strong class="c-red">{{ R$(resumoBancoItau.saidas) }}</strong></div>
              </div>
            </div>
            <p v-if="!(temContasPagbank || resumoBancoPagbank.receitas || resumoBancoPagbank.saidas) && !(temContasItau || resumoBancoItau.receitas || resumoBancoItau.saidas)" class="mn-vazio">
              Nenhuma conta com movimento neste período.
            </p>
          </div>
        </section>

        <!-- ── Mês a mês ── -->
        <section v-if="relatorioMensalFiltrado.length" class="mn-bloco">
          <header class="mn-bloco-cab">
            <h4 class="mn-bloco-titulo">{{ mesFiltroMensal ? 'Detalhes do mês' : 'Mês a mês' }}</h4>
            <span class="mn-bloco-sub">{{ relatorioMensalFiltrado.length }} {{ relatorioMensalFiltrado.length === 1 ? 'mês' : 'meses' }}</span>
          </header>

          <article v-for="item in relatorioMensalFiltrado" :key="item.mes_ref" class="mn-card mn-mes-card">
            <div class="mn-mes-cab">
              <h5 class="mn-mes-nome">{{ item.mes_ref }}</h5>
              <span class="mn-chip">{{ item.quantidade }} {{ item.quantidade === 1 ? 'lançamento' : 'lançamentos' }}</span>
            </div>

            <!-- O resultado do mês vem primeiro: é o que a pessoa quer saber -->
            <div class="mn-destaque" :class="item.saldo_mes >= 0 ? 'mn-destaque--ok' : 'mn-destaque--neg'">
              <span class="mn-destaque-lbl">{{ item.saldo_mes >= 0 ? 'Sobrou no mês' : 'Faltou no mês' }}</span>
              <strong class="mn-destaque-valor">{{ R$(item.saldo_mes) }}</strong>
            </div>

            <!-- Receita MEI, Despesas Operacionais (já inclui insumos) e Despesas Casa.
                 Nas listas de lançamentos continua "Retiradas pessoais"; só aqui muda o nome. -->
            <div class="mn-linhas">
              <div class="mn-linha">
                <span class="mn-ponto mn-ponto--verde"></span>
                <span class="mn-linha-lbl">Receita MEI</span>
                <strong class="c-green">{{ R$(item.receitas_mei) }}</strong>
              </div>
              <div class="mn-linha">
                <span class="mn-ponto mn-ponto--vermelho"></span>
                <span class="mn-linha-lbl">Despesas operacionais</span>
                <strong class="c-red">{{ R$(item.saidas_operacionais) }}</strong>
              </div>
              <div class="mn-linha">
                <span class="mn-ponto mn-ponto--vermelho"></span>
                <span class="mn-linha-lbl">Despesas pessoais</span>
                <strong class="c-red">{{ R$(item.saidas_pessoais) }}</strong>
              </div>
            </div>

            <!-- Composição completa: escondida até a pessoa pedir -->
            <button class="mn-toggle" :aria-expanded="!!detalhesMensalAbertos[item.mes_ref]" @click="toggleDetalhesMensal(item.mes_ref)">
              <i class="fas fa-list-ul"></i>
              <span>{{ detalhesMensalAbertos[item.mes_ref] ? 'Esconder composição' : 'Ver composição do mês' }}</span>
              <i class="fas mn-toggle-seta" :class="detalhesMensalAbertos[item.mes_ref] ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
            </button>
            <Transition name="fade-slide">
              <div v-if="detalhesMensalAbertos[item.mes_ref]" class="mn-detalhe">
                <div class="mn-grupo">
                  <div class="mn-grupo-titulo">Entradas</div>
                  <div class="mn-linha mn-linha--simples"><span class="mn-linha-lbl">Receita MEI (vendas)</span><strong class="c-green">{{ R$(item.receitas_mei) }}</strong></div>
                  <div v-if="item.outras_entradas_nao_mei" class="mn-linha mn-linha--simples">
                    <span class="mn-linha-lbl">Outras entradas (não-MEI)</span>
                    <strong class="c-purple">{{ R$(item.outras_entradas_nao_mei) }}</strong>
                  </div>
                  <div class="mn-linha mn-linha--simples"><span class="mn-linha-lbl">Rendimento</span><strong>{{ R$(item.rendimento_financeiro) }}</strong></div>
                  <div class="mn-linha mn-linha--simples mn-linha--total"><span class="mn-linha-lbl">Entrada bruta (banco)</span><strong class="c-blue">{{ R$(item.entradas) }}</strong></div>
                </div>
                <div class="mn-grupo">
                  <div class="mn-grupo-titulo">Saídas e resultado</div>
                  <div class="mn-linha mn-linha--simples"><span class="mn-linha-lbl">Despesas operacionais</span><strong class="c-red">{{ R$(item.saidas_operacionais) }}</strong></div>
                  <div class="mn-linha mn-linha--simples"><span class="mn-linha-lbl">Despesas pessoais</span><strong class="c-red">{{ R$(item.saidas_pessoais) }}</strong></div>
                  <div class="mn-linha mn-linha--simples mn-linha--total"><span class="mn-linha-lbl">Saldo do negócio</span><strong :class="item.saldo_operacional >= 0 ? 'c-green' : 'c-red'">{{ R$(item.saldo_operacional) }}</strong></div>
                </div>
              </div>
            </Transition>
          </article>
        </section>

        <!-- ── Por categoria ── -->
        <section class="mn-bloco">
          <header class="mn-bloco-cab">
            <h4 class="mn-bloco-titulo">Por categoria</h4>
            <span class="mn-bloco-sub">{{ mesFiltroMensal || anoFiltroMensal }}<template v-if="categoriasPorAno.length"> · {{ categoriasPorAno.length }}</template></span>
          </header>
          <div class="mn-card">
            <p v-if="!categoriasPorAno.length" class="mn-vazio">Sem dados para o período.</p>
            <template v-else>
              <div v-for="item in categoriasPorAno" :key="item.categoria" class="mn-cat">
                <span class="mn-ponto" :class="item.natureza === 'entrada' ? 'mn-ponto--verde' : 'mn-ponto--vermelho'"></span>
                <div class="mn-cat-txt">
                  <div class="mn-cat-nome">{{ item.categoria }}</div>
                  <div class="mn-cat-sub">{{ item.quantidade }} {{ item.quantidade === 1 ? 'lançamento' : 'lançamentos' }}<template v-if="item.natureza"> · <span class="mn-nat">{{ item.natureza === 'entrada' ? 'Entrada' : item.natureza === 'saida' ? 'Saída' : item.natureza }}</span></template></div>
                </div>
                <strong class="mn-cat-valor" :class="item.natureza === 'entrada' ? 'c-green' : 'c-red'">{{ R$(item.total) }}</strong>
              </div>
            </template>
          </div>
        </section>
      </div>
    </template>

    <!-- ═══ ABA: META DE RETIRADA ═══ -->
    <template v-else-if="abaAtiva === 'mao-de-obra'">
      <div class="relatorio-wrap mo-pagina">
          <div class="mo-corpo">

            <header class="mo-cab">
              <h3 class="mo-titulo">Retirada e mão de obra</h3>
              <p class="mo-desc">Quanto você pode retirar com segurança em cada mês e quanto vale a sua hora de trabalho.</p>
            </header>

            <!-- Cabeçalho: as duas métricas globais, com o mesmo peso visual -->
            <div class="mtr-kpis">
              <div class="mtr-kpi">
                <div class="mtr-kpi-ico"><i class="fas fa-bullseye"></i></div>
                <div class="mtr-kpi-txt">
                  <span class="mtr-label">Meta de retirada</span>
                  <strong class="mtr-valor">{{ R$(s.company.meta_salario_mensal) }}</strong>
                  <span class="mtr-sub">Quanto você quer tirar por mês</span>
                </div>
              </div>
              <div class="mtr-kpi mtr-kpi--giro">
                <div class="mtr-kpi-ico"><i class="fas fa-shield-halved"></i></div>
                <div class="mtr-kpi-txt">
                  <span class="mtr-label">Giro de segurança</span>
                  <strong class="mtr-valor c-orange">{{ R$(s.sugestaoProvisionamentoSemanal) }}</strong>
                  <span class="mtr-sub">Reservado p/ próxima compra de insumos</span>
                </div>
              </div>
            </div>

            <!-- Lista de meses -->
            <div v-if="s.resumoProducaoPorMes.length" class="mtr-lista">
              <div v-for="mes in s.resumoProducaoPorMes" :key="mes.mes_ref" class="mtr-card">

                <!-- Linha topo: mês + selo de status -->
                <div class="mtr-card-topo">
                  <span class="mtr-card-mes">{{ mes.mes_ref }}</span>
                  <span class="mtr-badge"
                    :class="retirSegura(mes) >= (s.metaSalarioEm(mes.mes_ref) || 0) ? 'mtr-badge--ok' : retirSegura(mes) > 0 ? 'mtr-badge--parcial' : 'mtr-badge--baixo'">
                    {{ retirSegura(mes) >= (s.metaSalarioEm(mes.mes_ref) || 0) ? 'Meta atingida' : retirSegura(mes) > 0 ? 'Abaixo da meta' : 'Sem margem' }}
                  </span>
                </div>

                <!-- Número principal: o que realmente importa nesse card -->
                <div class="mtr-card-principal">
                  <span class="mtr-card-principal-lbl">Retirada segura</span>
                  <strong class="mtr-card-retirada" :class="retirSegura(mes) >= (s.metaSalarioEm(mes.mes_ref) || 0) ? 'c-green' : retirSegura(mes) > 0 ? 'c-orange' : 'c-red'">
                    {{ R$(Math.max(0, retirSegura(mes))) }}
                  </strong>
                </div>

                <div v-if="retiradoMes(mes) > 0" class="mtr-retirado">
                  <span>Já retirado no mês <strong>{{ R$(retiradoMes(mes)) }}</strong></span>
                  <span>Ainda disponível <strong :class="aindaDisponivel(mes) > 0 ? 'c-green' : 'c-red'">{{ R$(Math.max(0, aindaDisponivel(mes))) }}</strong></span>
                </div>
                <div v-if="mes.a_classificar_qtd > 0" class="fin-aviso fin-aviso--mini">
                  <i class="fas fa-circle-question"></i>
                  <span>{{ mes.a_classificar_qtd }} {{ mes.a_classificar_qtd === 1 ? 'lançamento' : 'lançamentos' }} ({{ R$(mes.a_classificar_valor) }}) em "A classificar" contam como despesa. Se forem retiradas, mude para Pró-labore / Retirada.</span>
                </div>

                <!-- Barra de progresso em relação à meta -->
                <div class="mtr-bar-row">
                  <div class="mtr-bar-bg" aria-hidden="true">
                    <div class="mtr-bar-fill"
                      :style="{
                        width: s.metaSalarioEm(mes.mes_ref)
                          ? Math.min(100, Math.max(0, retirSegura(mes)) / s.metaSalarioEm(mes.mes_ref) * 100) + '%'
                          : '0%',
                        background: retirSegura(mes) >= (s.metaSalarioEm(mes.mes_ref) || 0) ? 'var(--green)' : 'var(--accent)'
                      }">
                    </div>
                  </div>
                  <span class="mtr-bar-pct">
                    {{ s.metaSalarioEm(mes.mes_ref) ? Math.round(Math.min(100, Math.max(0, retirSegura(mes)) / s.metaSalarioEm(mes.mes_ref) * 100)) : 0 }}%
                  </span>
                </div>

                <!-- Indicador de mão de obra (só aparece se horas foram registradas) -->
                <div v-if="mes.total_tempo_horas > 0" class="mtr-labor">
                  <i class="fas fa-clock"></i>
                  <span>{{ mes.total_tempo_horas.toFixed(1) }}h registradas</span>
                  <span class="mtr-labor-sep">·</span>
                  <span :class="mes.valor_hora_real >= s.company.custo_hora_trabalho ? 'c-green' : 'c-red'">
                    {{ R$(mes.valor_hora_real) }}/h real
                  </span>
                  <span class="mtr-labor-meta">(meta {{ R$(s.company.custo_hora_trabalho) }}/h)</span>
                </div>

                <!-- Detalhes do cálculo — escondido por padrão pra não poluir o card -->
                <button class="mtr-detalhes-toggle" @click="toggleDetalhesMes(mes.mes_ref)">
                  <span><i class="fas fa-calculator"></i> Ver como foi calculado</span>
                  <i class="fas" :class="detalhesAbertos[mes.mes_ref] ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
                </button>
                <Transition name="fade-slide">
                  <div v-if="detalhesAbertos[mes.mes_ref]" class="mtr-equacao">
                    <div class="mtr-eq-row">
                      <span>Vendas</span>
                      <strong class="c-green">{{ R$(mes.receitas_reais_banco) }}</strong>
                    </div>
                    <div class="mtr-eq-row mtr-eq-row--sub">
                      <span>− Despesas</span>
                      <strong class="c-red">{{ R$(mes.despesas_reais_banco) }}</strong>
                    </div>
                    <div class="mtr-eq-row mtr-eq-row--sub">
                      <span>− Reserva (giro)</span>
                      <strong class="c-orange">{{ R$(s.reservaGiroEm(mes.mes_ref)) }}</strong>
                    </div>
                    <div class="mtr-eq-row mtr-eq-row--result">
                      <span>= Retirada segura</span>
                      <strong :class="retirSegura(mes) >= 0 ? 'c-green' : 'c-red'">{{ R$(retirSegura(mes)) }}</strong>
                    </div>
                    <template v-if="retiradoMes(mes) > 0">
                      <div class="mtr-eq-row mtr-eq-row--sub">
                        <span>− Já retirado no mês</span>
                        <strong class="c-orange">{{ R$(retiradoMes(mes)) }}</strong>
                      </div>
                      <div class="mtr-eq-row mtr-eq-row--result">
                        <span>= Ainda disponível</span>
                        <strong :class="aindaDisponivel(mes) >= 0 ? 'c-green' : 'c-red'">{{ R$(aindaDisponivel(mes)) }}</strong>
                      </div>
                    </template>
                  </div>
                </Transition>

              </div>
            </div>
            <div v-else class="mo-vazio"><i class="fas fa-chart-simple"></i><strong>Nenhum dado financeiro ainda</strong><span>Importe um extrato para ver aqui a retirada segura de cada mês.</span></div>

            <!-- Explicação do tempo de produção — colapsável, fica fora do caminho -->
            <button class="mtr-explainer-toggle" @click="explicacaoAberta = !explicacaoAberta">
              <span><i class="fas fa-lightbulb"></i> Para que serve registrar o tempo de produção?</span>
              <i class="fas" :class="explicacaoAberta ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
            </button>
            <Transition name="fade-slide">
              <div v-if="explicacaoAberta" class="mtr-explainer">
                <div class="mtr-exp-item">
                  <strong>Planejar o mês</strong>
                  <span>Sabendo quantos minutos cada receita leva, você consegue estimar quantas unidades é possível fazer em um dia ou semana — e se vai dar conta do volume necessário para atingir a meta.</span>
                </div>
                <div class="mtr-exp-item">
                  <strong>Medir a saúde do negócio</strong>
                  <span>O <em>R$/h real</em> mostra quanto cada hora trabalhada gerou de lucro real (sobra no banco). Se ficar abaixo da sua meta, o volume de vendas precisa subir ou os custos de insumos precisam ser revistos.</span>
                </div>
                <div class="mtr-exp-aviso">
                  <i class="fas fa-triangle-exclamation"></i>
                  Como nem toda produção é cronometrada, o R$/h real costuma ser maior do que aparece — o que é positivo. A referência principal para retirada sempre é o saldo do banco, não a estimativa de produção.
                </div>
              </div>
            </Transition>

          </div>
      </div>
    </template>

    <!-- ═══ ABA: ANUAL ═══ -->
    <template v-else-if="abaAtiva === 'anual'">
      <div class="relatorio-wrap an-pagina">

        <header class="an-cab">
          <h3 class="an-titulo">Resumo do ano</h3>
          <p class="an-desc">Quanto entrou, quanto saiu e o que sobrou em cada ano.</p>
        </header>

        <!-- Seletor de ano -->
        <div class="an-anos" role="radiogroup" aria-label="Ano">
          <button v-for="a in anosDisponiveis" :key="a" class="an-ano" :class="{ active: anoRelAnual === a }"
            role="radio" :aria-checked="anoRelAnual === a" @click="anoRelAnual = a">{{ a }}</button>
        </div>

        <!-- Resultado do ano em destaque -->
        <div class="an-hero" :class="totalAnual.saldo >= 0 ? 'an-hero--ok' : 'an-hero--neg'">
          <span class="an-hero-lbl">{{ totalAnual.saldo >= 0 ? 'Sobrou em ' + anoRelAnual : 'Faltou em ' + anoRelAnual }}</span>
          <strong class="an-hero-valor">{{ R$(totalAnual.saldo) }}</strong>
          <span class="an-hero-sub">Receita MEI − despesas operacionais</span>
        </div>

        <!-- De onde veio e para onde foi -->
        <section class="an-bloco">
          <header class="an-bloco-cab"><h4 class="an-bloco-titulo">Entradas e saídas</h4></header>
          <div class="an-card">
            <div class="an-linha">
              <span class="an-ponto an-ponto--verde"></span>
              <div class="an-linha-txt">
                <div class="an-linha-nome">Receita MEI</div>
                <div class="an-linha-sub">PIX de clientes (sem renda pessoal)</div>
              </div>
              <strong class="an-linha-valor c-green">{{ R$(totalAnual.receitas) }}</strong>
            </div>
            <div v-if="totalAnual.outras_entradas" class="an-linha">
              <span class="an-ponto an-ponto--roxo"></span>
              <div class="an-linha-txt">
                <div class="an-linha-nome">Entradas não-MEI</div>
                <div class="an-linha-sub">Renda pessoal e rendimentos. Não contam no faturamento MEI</div>
              </div>
              <strong class="an-linha-valor c-purple">{{ R$(totalAnual.outras_entradas) }}</strong>
            </div>
            <div class="an-linha">
              <span class="an-ponto an-ponto--vermelho"></span>
              <div class="an-linha-txt">
                <div class="an-linha-nome">Despesas operacionais</div>
                <div class="an-linha-sub">Insumos, mercado, serviços</div>
              </div>
              <strong class="an-linha-valor c-red">{{ R$(totalAnual.operacional) }}</strong>
            </div>
            <div class="an-linha">
              <span class="an-ponto"></span>
              <div class="an-linha-txt">
                <div class="an-linha-nome">Despesas pessoais</div>
                <div class="an-linha-sub">Moradia, transferências</div>
              </div>
              <strong class="an-linha-valor">{{ R$(totalAnual.pessoal) }}</strong>
            </div>
          </div>
        </section>

        <!-- Gráfico de barras (CSS) -->
        <section v-if="relatorioAnualMeses.length" class="an-bloco">
          <header class="an-bloco-cab"><h4 class="an-bloco-titulo">Evolução mensal</h4></header>
          <div class="an-card an-card--pad">
            <div class="an-legenda">
              <span class="an-leg an-leg--verde"><i></i> Receita MEI</span>
              <span class="an-leg an-leg--vermelho"><i></i> Saída operacional</span>
            </div>
            <div class="grafico-barras an-grafico">
              <div v-for="item in relatorioAnualMeses" :key="item.mes_ref" class="barra-grupo">
                <div class="barra-labels">
                  <div class="barra entrada" :style="{ height: barraAltura(item.receitas_mei) + 'px' }" :title="'Receita: ' + R$(item.receitas_mei)"></div>
                  <div class="barra saida" :style="{ height: barraAltura(item.saidas_operacionais) + 'px' }" :title="'Saída: ' + R$(item.saidas_operacionais)"></div>
                </div>
                <div class="barra-mes">{{ item.mes_ref.split('/')[0] }}/{{ item.mes_ref.split('/')[1].slice(2) }}</div>
              </div>
            </div>
          </div>
        </section>

        <!-- Tabela mensal -->
        <section v-if="relatorioAnualMeses.length" class="an-bloco">
          <header class="an-bloco-cab"><h4 class="an-bloco-titulo">Mês a mês</h4></header>
          <div class="an-card">
            <div class="an-tabela">
              <div class="an-th"><span>Mês</span><span>Receita MEI</span><span>Saldo</span></div>
              <div v-for="item in relatorioAnualMeses" :key="item.mes_ref" class="an-tr">
                <span class="an-td-mes">{{ item.mes_ref }}</span>
                <span class="c-green">{{ R$(item.receitas_mei) }}</span>
                <span :class="item.saldo_operacional >= 0 ? 'c-green' : 'c-red'">{{ R$(item.saldo_operacional) }}</span>
              </div>
            </div>
          </div>
        </section>

        <div v-if="!relatorioAnualMeses.length" class="app-empty">
          <i class="fas fa-chart-bar"></i>
          <p>Sem dados para {{ anoRelAnual }}.</p>
          <button class="btn btn-primary" @click="abaAtiva = 'importar'">
            <i class="fas fa-file-import"></i> Importar extrato
          </button>
        </div>
      </div>
    </template>

    <template v-else-if="abaAtiva === 'relatorios'">
      <div class="relatorio-wrap rl-pagina">

        <header class="rl-cab">
          <h3 class="rl-titulo">Relatórios oficiais</h3>
          <p class="rl-desc">Livro Caixa do mês e Declaração Anual (DASN-SIMEI) do seu MEI, para conferir aqui e gerar em PDF.</p>
        </header>

        <!-- ── Seletor tipo relatório ── -->
        <div class="rel-tipo-nav" role="radiogroup" aria-label="Tipo de relatório">
          <button class="rel-tipo-btn" :class="{ active: relTipo === 'mensal' }" role="radio" :aria-checked="relTipo === 'mensal'" @click="relTipo = 'mensal'">
            <i class="fas fa-calendar-days"></i> Livro Caixa mensal
          </button>
          <button class="rel-tipo-btn" :class="{ active: relTipo === 'anual' }" role="radio" :aria-checked="relTipo === 'anual'" @click="relTipo = 'anual'">
            <i class="fas fa-file-invoice-dollar"></i> Declaração anual
          </button>
        </div>

        <!-- ══ BARRA TETO MEI ════════════════════════════ -->
        <section class="sheet-card teto-card">
          <div class="sheet-body">
            <div class="teto-header">
              <div>
                <div class="teto-titulo">Faturamento MEI · {{ anoRelatorioAtual }}</div>
                <div class="teto-sub">Limite anual: {{ R$(TETO_MEI_ANUAL) }}<template v-if="mesesAtividadeNoAno < 12"> · proporcional a {{ mesesAtividadeNoAno }} {{ mesesAtividadeNoAno === 1 ? 'mês' : 'meses' }} de atividade</template></div>
              </div>
              <div class="teto-valor-wrap">
                <div class="teto-valor" :class="percentualTeto >= 90 ? 'c-red' : percentualTeto >= 70 ? 'c-orange' : 'c-green'">
                  {{ R$(faturamentoAnoRel) }}
                </div>
                <div class="teto-pct">{{ percentualTeto.toFixed(1) }}% do teto</div>
              </div>
            </div>
            <div class="teto-barra-wrap">
              <div class="teto-barra-bg">
                <div class="teto-barra-fill"
                  :style="{ width: Math.min(100, percentualTeto) + '%' }"
                  :class="percentualTeto >= 90 ? 'danger' : percentualTeto >= 70 ? 'warning' : 'ok'">
                </div>
                <div class="teto-barra-mark" v-if="percentualTeto < 100" :title="'Faltam ' + R$(TETO_MEI_ANUAL - faturamentoAnoRel)">
                  <span class="teto-falta">Faltam {{ R$(Math.max(0, TETO_MEI_ANUAL - faturamentoAnoRel)) }}</span>
                </div>
              </div>
            </div>
            <div class="teto-alertas" v-if="percentualTeto >= 70">
              <div class="teto-alerta" :class="percentualTeto >= 90 ? 'alerta-danger' : 'alerta-warning'">
                <i class="fas" :class="percentualTeto >= 90 ? 'fa-triangle-exclamation' : 'fa-circle-info'"></i>
                <span v-if="percentualTeto > 120">Passou de 20% acima do teto ({{ R$(faturamentoAnoRel - TETO_MEI_ANUAL) }} a mais). Pode haver desenquadramento do MEI com efeito retroativo. Procure seu contador com urgência.</span>
                <span v-else-if="percentualTeto >= 100">Teto ultrapassado em {{ R$(faturamentoAnoRel - TETO_MEI_ANUAL) }}, dentro da tolerância de 20% (até {{ R$(TETO_COM_TOLERANCIA) }}). O excedente gera DAS complementar e, acima da tolerância, há desenquadramento. Confirme com seu contador.</span>
                <span v-else-if="percentualTeto >= 90">Atenção: mais de 90% do teto atingido. Monitore os próximos recebimentos.</span>
                <span v-else>Mais de 70% do teto utilizado. Fique atento ao limite.</span>
              </div>
            </div>
          </div>
        </section>

        <!-- ══ RELATÓRIO MENSAL — LIVRO CAIXA ══════════════ -->
        <template v-if="relTipo === 'mensal'">
          <section class="sheet-card">
            <div class="sheet-body">
              <div class="section-head">
                <h4><i class="fas fa-calendar-days"></i> Livro Caixa MEI · Mensal</h4>
              </div>

              <div class="report-config-box">
                <div class="report-config-grid">
                  <div class="fg" style="margin:0">
                    <label class="label">Competência</label>
                    <select class="input sm" v-model="relMensalMesRef">
                      <option v-for="m in mesesRelatorio" :key="m.value" :value="m.value">{{ m.label }}</option>
                    </select>
                  </div>
                  <div class="fg rl-fg-switch" style="margin:0">
                    <label class="rl-switch-linha">
                      <span>Incluir rendas pessoais</span>
                      <input type="checkbox" role="switch" class="rl-switch" v-model="incluirRendasPessoais" />
                    </label>
                  </div>
                </div>
                <button class="btn-gerar-large" @click="gerarDocLivroCaixa">
                  <i class="fas fa-file-pdf"></i> Gerar Livro Caixa (PDF)
                </button>
              </div>

              <!-- Cabeçalho formal -->
              <div class="lc-cabecalho" v-if="dadosRelMensal">
                <div class="lc-cb-linha"><span>Contribuinte (MEI):</span><strong>{{ nomeContribuinte }}</strong></div>
                <div class="lc-cb-linha"><span>Competência:</span><strong>{{ relMensalMesRef }}</strong></div>
                <div class="lc-cb-linha"><span>Atividade:</span><strong>Produção e venda de alimentos artesanais</strong></div>
              </div>

              <div v-if="dadosRelMensal && dadosRelMensal.a_classificar_qtd > 0" class="fin-aviso">
                <i class="fas fa-circle-question"></i>
                <span>{{ dadosRelMensal.a_classificar_qtd }} {{ dadosRelMensal.a_classificar_qtd === 1 ? 'lançamento' : 'lançamentos' }} ({{ R$(dadosRelMensal.a_classificar_valor) }}) em <strong>A classificar</strong>: contam como despesa até você revisar. Se forem retiradas, mude para Pró-labore / Retirada (o app aprende a descrição).</span>
              </div>
              <div v-if="!dadosRelMensal" class="empty-mini">Sem dados para este mês.</div>
              <template v-else>

                <!-- Tabela Receitas -->
                <div class="lc-section-label entrada">↑ RECEITAS / ENTRADAS</div>
                <div class="lc-tabela">
                  <FinanceListRow v-for="item in lancMensalEntradas" :key="item.id" class="lc-row entrada-row" variant="entrada" :interactive="false">
                    <div class="lc-col-top">
                      <span class="lc-badge lc-entrada">{{ item.categoria }}</span>
                      <span class="lc-col-val c-green">{{ R$(item.valor) }}</span>
                    </div>
                    <div class="lc-col-desc">{{ item.descricao }}</div>
                    <div class="lc-col-data">{{ formatarData(item.data) }}</div>
                  </FinanceListRow>
                  <div v-if="!lancMensalEntradas.length" class="lc-vazio">Nenhuma receita neste mês.</div>
                  <div v-if="dadosRelMensal.estornos_receita > 0" class="lc-estorno">
                    <span>Estornos e devoluções (já abatidos do faturamento)</span>
                    <strong class="c-red">− {{ R$(dadosRelMensal.estornos_receita) }}</strong>
                  </div>
                  <div class="lc-total">
                    <span class="lc-total-label">Total Receita MEI (faturamento)</span>
                    <strong class="c-green">{{ R$(dadosRelMensal.receitas_mei) }}</strong>
                  </div>
                </div>

                <!-- Entradas não-MEI (informativo) -->
                <template v-if="lancMensalNaoMei.length">
                  <div class="lc-section-label pessoal">↑ OUTRAS ENTRADAS (não compõem faturamento MEI)</div>
                  <div class="lc-tabela">
                    <FinanceListRow v-for="item in lancMensalNaoMei" :key="item.id" class="lc-row pessoal-row" variant="pessoal" :interactive="false">
                      <div class="lc-col-top">
                        <span class="lc-badge lc-pessoal">{{ item.categoria }}</span>
                        <span class="lc-col-val c-purple">{{ R$(item.valor) }}</span>
                      </div>
                      <div class="lc-col-desc">{{ item.descricao }}</div>
                      <div class="lc-col-data">{{ formatarData(item.data) }}</div>
                    </FinanceListRow>
                    <div class="lc-total pessoal-total">
                      <span class="lc-total-label">Total Outras Entradas</span>
                      <strong class="c-purple">{{ R$(dadosRelMensal.outras_entradas_nao_mei) }}</strong>
                    </div>
                  </div>
                </template>

                <!-- Tabela Despesas Operacionais -->
                <div class="lc-section-label saida">↓ DESPESAS OPERACIONAIS</div>
                <div class="lc-tabela">
                  <FinanceListRow v-for="item in lancMensalSaidasParaDoc" :key="item.id" class="lc-row saida-row" variant="saida" :interactive="false">
                    <div class="lc-col-top">
                      <span class="lc-badge lc-saida">{{ item.categoria }}</span>
                      <span class="lc-col-val c-red">{{ R$(Math.abs(item.valor)) }}</span>
                    </div>
                    <div class="lc-col-desc">{{ item.descricao }}</div>
                    <div class="lc-col-data">{{ formatarData(item.data) }}</div>
                  </FinanceListRow>
                  <div v-if="!lancMensalSaidasParaDoc.length" class="lc-vazio">Nenhuma despesa operacional.</div>
                  <div class="lc-total">
                    <span class="lc-total-label">Total Despesas Operacionais</span>
                    <strong class="c-red">{{ R$(dadosRelMensal.saidas_operacionais) }}</strong>
                  </div>
                </div>

                <!-- Resumo do mês -->
                <div class="lc-resumo">
                  <div class="lc-resumo-linha">
                    <span>Receita MEI bruta</span>
                    <strong class="c-green">{{ R$(dadosRelMensal.receitas_mei) }}</strong>
                  </div>
                  <div class="lc-resumo-linha" v-if="dadosRelMensal.outras_entradas_nao_mei">
                    <span>Outras entradas (não-MEI)</span>
                    <strong class="c-purple">{{ R$(dadosRelMensal.outras_entradas_nao_mei) }}</strong>
                  </div>
                  <div class="lc-resumo-linha">
                    <span>( − ) Despesas operacionais</span>
                    <strong class="c-red">{{ R$(dadosRelMensal.saidas_operacionais) }}</strong>
                  </div>
                  <div class="lc-resumo-linha destaque">
                    <span>= Resultado operacional MEI</span>
                    <strong :class="dadosRelMensal.saldo_operacional >= 0 ? 'c-green' : 'c-red'">
                      {{ R$(dadosRelMensal.saldo_operacional) }}
                    </strong>
                  </div>
                  <div class="lc-resumo-linha sub">
                    <span>Rendimentos financeiros</span>
                    <strong>{{ R$(dadosRelMensal.rendimento_financeiro) }}</strong>
                  </div>
                  <div class="lc-resumo-linha sub">
                    <span>Retiradas pessoais / Pró-labore</span>
                    <strong class="c-red">{{ R$(dadosRelMensal.saidas_pessoais) }}</strong>
                  </div>
                </div>

                <!-- Acumulado do ano -->
                <div class="lc-acumulado">
                  <div class="lc-acum-titulo">Acumulado {{ anoRelatorioAtual }} até {{ relMensalMesRef }}</div>
                  <div class="lc-acum-grid">
                    <div class="lc-acum-item">
                      <span>Faturamento MEI</span>
                      <strong class="c-green">{{ R$(acumuladoAteMes.receitas_mei) }}</strong>
                    </div>
                    <div class="lc-acum-item">
                      <span>Despesas operacionais</span>
                      <strong class="c-red">{{ R$(acumuladoAteMes.saidas_operacionais) }}</strong>
                    </div>
                    <div class="lc-acum-item">
                      <span>Resultado acumulado</span>
                      <strong :class="acumuladoAteMes.saldo_operacional >= 0 ? 'c-green' : 'c-red'">
                        {{ R$(acumuladoAteMes.saldo_operacional) }}
                      </strong>
                    </div>
                    <div class="lc-acum-item">
                      <span>% do teto MEI</span>
                      <strong :class="acumuladoAteMes.pct_teto >= 90 ? 'c-red' : acumuladoAteMes.pct_teto >= 70 ? 'c-orange' : 'c-green'">
                        {{ acumuladoAteMes.pct_teto.toFixed(1) }}%
                      </strong>
                    </div>
                  </div>
                </div>

              </template>
            </div>
          </section>
        </template>

        <!-- ══ RELATÓRIO ANUAL — DASN-SIMEI ═══════════════ -->
        <template v-if="relTipo === 'anual'">
          <section class="sheet-card">
            <div class="sheet-body">
              <div class="section-head">
                <h4><i class="fas fa-file-invoice-dollar"></i> Declaração Anual · DASN-SIMEI</h4>
              </div>

              <div class="report-config-box">
                <div class="report-config-grid">
                  <div class="fg" style="margin:0">
                    <label class="label">Ano-calendário</label>
                    <select class="input sm" v-model="anoRelAnual">
                      <option v-for="a in anosDisponiveis" :key="a" :value="a">{{ a }}</option>
                    </select>
                  </div>
                  <div class="fg rl-fg-switch" style="margin:0">
                    <label class="rl-switch-linha">
                      <span>Incluir rendas pessoais</span>
                      <input type="checkbox" role="switch" class="rl-switch" v-model="incluirRendasPessoais" />
                    </label>
                  </div>
                </div>
                <button class="btn-gerar-large" @click="gerarDocDASN">
                  <i class="fas fa-file-arrow-down"></i> Gerar DASN-SIMEI Oficial
                </button>
              </div>

              <div class="lc-cabecalho">
                <div class="lc-cb-linha"><span>Contribuinte (MEI):</span><strong>{{ nomeContribuinte }}</strong></div>
                <div class="lc-cb-linha"><span>Ano-calendário:</span><strong>{{ anoRelAnual }}</strong></div>
                <div class="lc-cb-linha"><span>Documento:</span><strong>DASN-SIMEI — Declaração Anual do Simples Nacional MEI</strong></div>
              </div>

              <!-- Quadro 1: Receita Bruta MEI -->
              <div class="lc-section-label entrada">QUADRO 1 — RECEITA BRUTA MEI</div>
              <div class="lc-quadro">
                <div class="lc-q-linha hdr">
                  <span>Mês</span>
                  <span>Receita MEI</span>
                  <span>Acumulado</span>
                </div>
                <div v-for="(item, idx) in relatorioAnualMeses" :key="item.mes_ref" class="lc-q-linha">
                  <span class="lc-q-mes">{{ item.mes_ref }}</span>
                  <span class="c-green">{{ R$(item.receitas_mei) }}</span>
                  <span class="c-green">{{ R$(relatorioAnualMeses.slice(0, idx+1).reduce((a,i)=>a+i.receitas_mei,0)) }}</span>
                </div>
                <div v-if="!relatorioAnualMeses.length" class="lc-vazio">Sem dados para o ano.</div>
                <div class="lc-q-linha total">
                  <span>TOTAL</span>
                  <span class="c-green fw700">{{ R$(totalAnual.receitas) }}</span>
                  <span class="c-green fw700">{{ R$(totalAnual.receitas) }}</span>
                </div>
              </div>

              <!-- Quadro 2: Outras entradas (informativo) -->
              <div class="lc-section-label pessoal" v-if="incluirRendasPessoais && totalAnual.outras_entradas">
                INFORMATIVO — ENTRADAS NÃO-MEI
              </div>
              <div class="lc-quadro" v-if="incluirRendasPessoais && totalAnual.outras_entradas">
                <div class="lc-q-linha hdr">
                  <span>Tipo</span>
                  <span>Total {{ anoRelAnual }}</span>
                </div>
                <div class="lc-q-linha">
                  <span class="lc-q-mes">Renda pessoal</span>
                  <span class="c-purple fw700">{{ R$(totalAnual.outras_entradas) }}</span>
                </div>
              </div>

              <!-- Quadro 3: Despesas operacionais -->
              <div class="lc-section-label saida">QUADRO 2 — DESPESAS DO EXERCÍCIO</div>
              <div class="lc-quadro">
                <div class="lc-q-linha hdr">
                  <span>Mês</span>
                  <span>Op.</span>
                  <span>Pessoal</span>
                </div>
                <div v-for="item in relatorioAnualMeses" :key="item.mes_ref" class="lc-q-linha">
                  <span class="lc-q-mes">{{ item.mes_ref }}</span>
                  <span class="c-red">{{ R$(item.saidas_operacionais) }}</span>
                  <span>{{ R$(item.saidas_pessoais) }}</span>
                </div>
                <div class="lc-q-linha total">
                  <span>TOTAL</span>
                  <span class="c-red fw700">{{ R$(totalAnual.operacional) }}</span>
                  <span class="fw700">{{ R$(totalAnual.pessoal) }}</span>
                </div>
              </div>

              <!-- Quadro resumo final -->
              <div class="lc-section-label">RESULTADO DO EXERCÍCIO {{ anoRelAnual }}</div>
              <div class="lc-resumo-anual">
                <div class="lra-linha">
                  <span>Receita Bruta MEI (faturamento tributável)</span>
                  <strong class="c-green">{{ R$(totalAnual.receitas) }}</strong>
                </div>
                <div class="lra-linha" v-if="incluirRendasPessoais && totalAnual.outras_entradas">
                  <span>Outras entradas não-MEI (informativo)</span>
                  <strong class="c-purple">{{ R$(totalAnual.outras_entradas) }}</strong>
                </div>
                <div class="lra-linha">
                  <span>( − ) Total de despesas operacionais</span>
                  <strong class="c-red">{{ R$(totalAnual.operacional) }}</strong>
                </div>
                <div class="lra-linha destaque">
                  <span>= Resultado líquido do negócio</span>
                  <strong :class="totalAnual.saldo >= 0 ? 'c-green' : 'c-red'">{{ R$(totalAnual.saldo) }}</strong>
                </div>
                <div class="lra-linha sub">
                  <span>Retiradas pessoais (Pró-labore)</span>
                  <strong>{{ R$(totalAnual.pessoal) }}</strong>
                </div>
                <div class="lra-verificacao">
                  <i class="fas" :class="totalAnual.receitas <= TETO_MEI_ANUAL ? 'fa-circle-check' : 'fa-triangle-exclamation'"></i>
                  <span v-if="totalAnual.receitas <= TETO_MEI_ANUAL">
                    Dentro do teto MEI ({{ R$(totalAnual.receitas) }} de {{ R$(TETO_MEI_ANUAL) }})
                  </span>
                  <span v-else>
                    Faturamento ACIMA do teto MEI — verificar obrigações com contador
                  </span>
                </div>
              </div>

            </div>
          </section>
        </template>

        <!-- Nota de rodapé -->
        <div class="rel-nota">
          <i class="fas fa-circle-info"></i>
          Teto MEI {{ anoRelatorioAtual }}: {{ R$(TETO_MEI_ANUAL) }}/ano · Dados gerados com base nos lançamentos importados.
          A DASN-SIMEI deve ser entregue até 31/05 do ano seguinte via portal gov.br/mei.
        </div>

      </div>
    </template>
    <!-- ── Barra flutuante de ações em lote ── -->
    <Transition name="barra-lote">
      <div v-if="modoSelecao && selecionados.size" class="barra-lote">
        <div class="barra-lote-info">
          <strong>{{ selecionados.size }}</strong>
          <span>selecionado{{ selecionados.size > 1 ? 's' : '' }}</span>
        </div>
        <button class="barra-btn cancel" @click="limparSelecao">
          <i class="fas fa-xmark"></i> Limpar
        </button>
        <button class="barra-btn primary" @click="abrirModalLote">
          <i class="fas fa-tag"></i> Categorizar
        </button>
      </div>
    </Transition>

    <!-- ── Modal edição unitária ── -->
    <EditarCategoriaModal
      v-if="lancamentoEmEdicao"
      :lancamento="lancamentoEmEdicao"
      @close="lancamentoEmEdicao = null"
      @salvo="lancamentoEmEdicao = null"
    />

    <!-- ── Modal edição em lote ── -->
    <EditarCategoriaModal
      v-if="modalLoteAberto"
      :ids="[...selecionados]"
      @close="modalLoteAberto = false"
      @salvo="onLoteSalvo"
    />
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue'
import ImportadorExtrato from '../components/ImportadorExtrato.vue'
import ImportadorItau from '../components/ImportadorItau.vue'
import ImportadorBancoBrasil from '../components/ImportadorBancoBrasil.vue'

import FinanceListRow from '../components/FinanceListRow.vue'
import EditarCategoriaModal from '../components/EditarCategoriaModal.vue'
import CategoryFilter from '../components/CategoryFilter.vue'
import { useStore } from '../store.js'
import { R$, formatarData, normalizar } from '../utils.js'
import { useConfirm as useAppConfirm } from '../composables/useConfirm.js'
import { gerarLivroCaixa, gerarDASNSIMEI } from '../composables/useGerarDocumento.js'
import { useTabScroll } from '../composables/useTabScroll.js'

const s = useStore()
const confirmar = useAppConfirm()
const lancamentoEmEdicao = ref(null)
const bancoImport = ref('pagbank')
const mostrarExcluirBanco = ref(false)
// Popover ativo na barra de filtros compacta: '', 'busca', 'periodo', 'banco', 'tipo' ou 'categoria'
const popoverAtivo = ref('')
function togglePopover(nome) {
  popoverAtivo.value = popoverAtivo.value === nome ? '' : nome
}

const filtrosAtivosCount = computed(() => {
  let count = 0
  if (filtroBanco.value) count++
  if (filtroCategoria.value) count++
  if (filtroNatureza.value) count++
  if (buscaDescricao.value) count++
  return count
})

// ── Lógica de visibilidade dos importadores baseada em contas configuradas ──
const temContasPagbank = computed(() => s.getContasFinanceirasPorBanco('pagbank').length > 0)
const temContasItau = computed(() => s.getContasFinanceirasPorBanco('itau').length > 0)
const temContasBb = computed(() => s.getContasFinanceirasPorBanco('bb').length > 0)
const temAlgumBancoConfigurado = computed(() => temContasPagbank.value || temContasItau.value || temContasBb.value)
const bancosImportacaoDisponiveis = computed(() => [
  { id: 'pagbank', tem: temContasPagbank.value },
  { id: 'itau', tem: temContasItau.value },
  { id: 'bb', tem: temContasBb.value }
].filter(b => b.tem))

function selecionarBancoImportacaoDisponivel() {
  const atualDisponivel = bancosImportacaoDisponiveis.value.some(b => b.id === bancoImport.value)
  if (!atualDisponivel && bancosImportacaoDisponiveis.value.length) {
    bancoImport.value = bancosImportacaoDisponiveis.value[0].id
  }
}

const grupos = [
  { id: 'diaadia', label: 'Dia a dia', icon: 'fas fa-calendar-day' },
  { id: 'mei',     label: 'MEI e Relatórios', icon: 'fas fa-file-invoice' }
]
const grupoAtivo = ref('diaadia')
const { stripEl: grupoStripEl, setTabRef: setGrupoRef } = useTabScroll(grupoAtivo)

const abas = [
  { id: 'importar',    label: 'Importar',       icon: 'fas fa-file-import',   grupo: 'diaadia' },
  { id: 'lancamentos', label: 'Movimentações', icon: 'fas fa-list',          grupo: 'diaadia' },
  { id: 'mensal',      label: 'Resumo Mensal',  icon: 'fas fa-calendar',      grupo: 'diaadia' },
  { id: 'mao-de-obra', label: 'Meta de Retirada', icon: 'fas fa-bullseye',    grupo: 'diaadia' },
  { id: 'anual',       label: 'Resumo Anual',   icon: 'fas fa-chart-bar',     grupo: 'mei' },
  { id: 'relatorios',  label: 'Documentos MEI', icon: 'fas fa-file-contract', grupo: 'mei' }
]
const abasVisiveis = computed(() => abas.filter(a => a.grupo === grupoAtivo.value))
const abaAtiva = ref('lancamentos')
const { stripEl: abaStripEl, setTabRef: setAbaRef } = useTabScroll(abaAtiva)

// Aba padrão de cada grupo — independe da ordem visual da tira de abas
// (ex.: "Importar" aparece antes na lista, mas "Movimentações" continua
// sendo a aba que abre por padrão).
const abaPadraoPorGrupo = { diaadia: 'lancamentos', mei: 'anual' }
watch(grupoAtivo, () => {
  abaAtiva.value = abaPadraoPorGrupo[grupoAtivo.value] || abasVisiveis.value[0]?.id
})

watch([abaAtiva, bancosImportacaoDisponiveis], () => {
  if (abaAtiva.value === 'importar') selecionarBancoImportacaoDisponivel()
}, { immediate: true })

// ── Filtros ──
const filtroBanco     = ref('')
const filtroMes       = ref('')
const filtroNatureza  = ref('')
const filtroCategoria = ref('')
const buscaDescricao = ref('')
const buscaNoExtratoInteiro = ref(false)

const filtrosBanco = computed(() => {
  const bancos = [
    { id: '',        label: 'Todos' }
  ]
  if (temContasPagbank.value) bancos.push({ id: 'pagbank', label: 'PagBank' })
  if (temContasItau.value)    bancos.push({ id: 'itau',    label: 'Itaú' })
  if (temContasBb.value)      bancos.push({ id: 'bb',      label: 'BB' })
  return bancos
})

const bancoAtivoLabel = computed(() =>
  filtrosBanco.value.find(b => b.id === filtroBanco.value)?.label || 'Banco'
)

const tipoAtivoLabel = computed(() => {
  if (filtroNatureza.value === 'entrada') return 'Receitas'
  if (filtroNatureza.value === 'operacional') return 'Custos'
  if (filtroNatureza.value === 'pessoal') return 'Pessoal'
  return 'Tipo'
})

const gruposCategoriasFiltro = computed(() => {
  const map = new Map()
  s.categoriasFinanceiro.forEach(cat => {
    if (!map.has(cat.grupo)) map.set(cat.grupo, { nome: cat.grupo, categorias: [] })
    map.get(cat.grupo).categorias.push(cat)
  })
  return [...map.values()]
})

function capitalizarDescricao(txt) {
  if (!txt) return ''
  return txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase()
}

function limparFiltros() {
  filtroBanco.value = filtroCategoria.value = filtroNatureza.value = ''
  buscaDescricao.value = ''
  buscaNoExtratoInteiro.value = false
  popoverAtivo.value = ''
}

const mesNavegacaoInicializada = ref(false)

const lancamentosBaseFiltrados = computed(() =>
  s.financeiro.filter(item => {
    if (filtroBanco.value && (item.banco || 'pagbank') !== filtroBanco.value) return false
    if (filtroMes.value && (item.mes_ref || '') !== filtroMes.value) return false
    if (filtroCategoria.value && item.categoria !== filtroCategoria.value) return false
    if (filtroNatureza.value && item.natureza !== filtroNatureza.value) return false
    return true
  })
)

const lancamentosFiltrados = computed(() => {
  const buscaNormalizada = normalizar(buscaDescricao.value)
  const base = buscaNoExtratoInteiro.value && buscaNormalizada
    ? s.financeiro
    : lancamentosBaseFiltrados.value

  if (!buscaNormalizada) return base

  return base.filter(item => normalizar(item.descricao).includes(buscaNormalizada))
})

const transInternasCount = computed(() =>
  lancamentosFiltrados.value.filter(i => i.natureza === 'interna').length
)

// Definição única de caixa (igual no card por banco, na lista e no "saldo do mês"):
// entrou = valor positivo, saiu = valor negativo, sem transferências entre contas próprias.
function totaisCaixa(items) {
  let entradas = 0, saidas = 0
  for (const i of items) {
    if (i.natureza === 'interna') continue
    if (i.valor > 0) entradas += i.valor
    else saidas -= i.valor
  }
  return { entradas, saidas, saldo: entradas - saidas }
}

const totalEntradas  = computed(() => totaisCaixa(lancamentosFiltrados.value).entradas)
const totalSaidas    = computed(() => totaisCaixa(lancamentosFiltrados.value).saidas)

const saldoFiltrado  = computed(() =>
  lancamentosFiltrados.value
    .filter(i => i.natureza !== 'interna')
    .reduce((a, i) => a + i.valor, 0)
)

const mesesDisponiveis = computed(() => {
  const set = new Set(s.financeiro.map(i => i.mes_ref).filter(Boolean))
  return [...set].sort((a, b) => {
    const [ma, aa] = a.split('/'), [mb, ab] = b.split('/')
    return `${ab}${mb}`.localeCompare(`${aa}${ma}`)
  })
})

const indiceMesAtual = computed(() => mesesDisponiveis.value.indexOf(filtroMes.value))
const temMesMaisNovo = computed(() => indiceMesAtual.value > 0)
const temMesMaisAntigo = computed(() =>
  indiceMesAtual.value >= 0 && indiceMesAtual.value < (mesesDisponiveis.value.length - 1)
)

watch(mesesDisponiveis, (meses) => {
  if (!meses.length) return
  if (!mesNavegacaoInicializada.value) {
    filtroMes.value = meses[0]
    mesNavegacaoInicializada.value = true
    return
  }
  if (filtroMes.value && !meses.includes(filtroMes.value)) {
    filtroMes.value = meses[0]
  }
}, { immediate: true })

function irParaMesMaisNovo() {
  if (!temMesMaisNovo.value) return
  filtroMes.value = mesesDisponiveis.value[indiceMesAtual.value - 1]
}

function irParaMesMaisAntigo() {
  if (!temMesMaisAntigo.value) return
  filtroMes.value = mesesDisponiveis.value[indiceMesAtual.value + 1]
}

const anosDisponiveis = computed(() => {
  const set = new Set(s.financeiro.map(i => (i.data || '').slice(0, 4)).filter(Boolean))
  return [...set].sort((a, b) => b.localeCompare(a))
})

// ── Mensal ──
const anoFiltroMensal = ref(String(new Date().getFullYear()))
const mesFiltroMensal = ref('')

const mesesParaFiltroMensal = computed(() => 
  mesesDisponiveis.value.filter(m => m.endsWith(`/${anoFiltroMensal.value}`))
)

const idxMesMensal = computed(() => mesesParaFiltroMensal.value.indexOf(mesFiltroMensal.value))

function irParaMesNovoMensal() {
  if (idxMesMensal.value > 0) mesFiltroMensal.value = mesesParaFiltroMensal.value[idxMesMensal.value - 1]
  else if (idxMesMensal.value === -1 && mesesParaFiltroMensal.value.length) mesFiltroMensal.value = mesesParaFiltroMensal.value[0]
}

function irParaMesAntigoMensal() {
  if (idxMesMensal.value >= 0 && idxMesMensal.value < mesesParaFiltroMensal.value.length - 1) {
    mesFiltroMensal.value = mesesParaFiltroMensal.value[idxMesMensal.value + 1]
  }
}

watch(anoFiltroMensal, () => { mesFiltroMensal.value = '' })

const relatorioMensalFiltrado = computed(() => {
  const base = s.relatorioMensalMei.filter(item => item.mes_ref.endsWith(`/${anoFiltroMensal.value}`))
  if (mesFiltroMensal.value) return base.filter(item => item.mes_ref === mesFiltroMensal.value)
  return base
})

function resumoBancoPorPeriodo(banco, ano, mes = '') {
  const items = s.financeiro.filter(i => {
    const isBanco = (i.banco || 'pagbank') === banco
    const isAno = (i.data || '').startsWith(ano)
    const isMes = mes ? i.mes_ref === mes : true
    return isBanco && isAno && isMes
  })
  // Transferências entre contas próprias (natureza 'interna') ficam de fora,
  // igual em todo o resto do Financeiro — mover dinheiro do PagBank pro Itaú
  // não é receita nem despesa do negócio.
  const { entradas, saidas, saldo } = totaisCaixa(items)
  return { receitas: entradas, saidas, saldo }
}

const resumoBancoPagbank = computed(() => resumoBancoPorPeriodo('pagbank', anoFiltroMensal.value, mesFiltroMensal.value))
const resumoBancoItau    = computed(() => resumoBancoPorPeriodo('itau',    anoFiltroMensal.value, mesFiltroMensal.value))

const categoriasPorAno = computed(() => {
  const map = new Map()
  s.financeiro
    .filter(i => {
      const aMatch = (i.data || '').startsWith(anoFiltroMensal.value)
      const mMatch = mesFiltroMensal.value ? i.mes_ref === mesFiltroMensal.value : true
      return aMatch && mMatch
    })
    .forEach(i => {
      const chave = i.categoria || 'Sem categoria'
      if (!map.has(chave)) map.set(chave, { categoria: chave, total: 0, quantidade: 0, natureza: i.natureza || '' })
      const a = map.get(chave)
      a.total += Math.abs(i.valor)
      a.quantidade += 1
    })
  return [...map.values()].sort((a, b) => b.total - a.total)
})

// ── Anual ──
const anoRelAnual = ref(String(new Date().getFullYear()))

const relatorioAnualMeses = computed(() =>
  s.relatorioMensalMei
    .filter(i => i.mes_ref.endsWith(`/${anoRelAnual.value}`))
    .sort((a, b) => Number(a.mes_ref.split('/')[0]) - Number(b.mes_ref.split('/')[0]))
)

const totalAnual = computed(() => {
  const m = relatorioAnualMeses.value
  return {
    receitas:       m.reduce((a, i) => a + i.receitas_mei, 0),
    outras_entradas: m.reduce((a, i) => a + (i.outras_entradas_nao_mei || 0), 0),
    operacional:    m.reduce((a, i) => a + i.saidas_operacionais, 0),
    pessoal:        m.reduce((a, i) => a + i.saidas_pessoais, 0),
    saldo:          m.reduce((a, i) => a + i.saldo_operacional, 0)
  }
})

const maxBarraValor = computed(() =>
  Math.max(1, ...relatorioAnualMeses.value.flatMap(i => [i.receitas_mei, i.saidas_operacionais]))
)

function barraAltura(valor) {
  return Math.max(2, Math.round((valor / maxBarraValor.value) * 60))
}

function selecionarCategoria(categoria) {
  filtroCategoria.value = categoria
  filtroNatureza.value = '' // Limpa o filtro de natureza ao selecionar uma categoria específica
  popoverAtivo.value = ''
}

function selecionarNatureza(natureza) {
  filtroNatureza.value = filtroNatureza.value === natureza ? '' : natureza
  filtroCategoria.value = '' // Limpa o filtro de categoria ao selecionar uma natureza
}

// ── Multi-seleção ──
const modoSelecao    = ref(false)
const selecionados   = ref(new Set())

// Long press para ativar seleção (500ms)
let _longPressTimer = null
function iniciarLongPress(item) {
  _longPressTimer = setTimeout(() => {
    if (!modoSelecao.value) {
      modoSelecao.value = true
      if (navigator.vibrate) navigator.vibrate(30)
    }
    const novo = new Set(selecionados.value)
    novo.add(item.id)
    selecionados.value = novo
  }, 500)
}
function cancelarLongPress() {
  clearTimeout(_longPressTimer)
}
const modalLoteAberto = ref(false)

function toggleSelecao() {
  modoSelecao.value = !modoSelecao.value
  if (!modoSelecao.value) selecionados.value = new Set()
}

function toggleItem(id) {
  const novo = new Set(selecionados.value)
  novo.has(id) ? novo.delete(id) : novo.add(id)
  selecionados.value = novo
}

const todosSelecionados = computed(() =>
  lancamentosFiltrados.value.length > 0 &&
  lancamentosFiltrados.value.every(i => selecionados.value.has(i.id))
)

function toggleSelecionarTodos() {
  if (todosSelecionados.value) {
    selecionados.value = new Set()
  } else {
    selecionados.value = new Set(lancamentosFiltrados.value.map(i => i.id))
  }
}

function limparSelecao() { selecionados.value = new Set() }

function abrirModalLote() { modalLoteAberto.value = true }

function abrirModalEdicao(item) {
  lancamentoEmEdicao.value = item
}

function onLoteSalvo() {
  modalLoteAberto.value = false
  selecionados.value = new Set()
  modoSelecao.value = false
}

const bancosComLancamentos = computed(() => {
  const config = [
    { id: 'pagbank', label: 'PagBank' },
    { id: 'itau',    label: 'Itaú' },
    { id: 'bb',      label: 'BB' }
  ]
  return config
    .map(b => ({ ...b, count: s.financeiro.filter(i => (i.banco || 'pagbank') === b.id).length }))
    .filter(b => b.count > 0)
})

async function handleExcluirPorBanco(banco) {
  const labels = { pagbank: 'PagBank', itau: 'Itaú', bb: 'BB', todos: 'todos os bancos' }
  const count = banco === 'todos'
    ? s.financeiro.length
    : s.financeiro.filter(i => (i.banco || 'pagbank') === banco).length
  const ok = await confirmar.ask(
    `Isso irá apagar permanentemente ${count} lançamento(s) de ${labels[banco] || banco}. Deseja continuar?`,
    { title: 'Excluir Extrato', icon: 'fas fa-trash-can', confirmLabel: 'Apagar', type: 'danger' }
  )
  if (ok) {
    await s.limparFinanceiroPorBanco(banco)
    mostrarExcluirBanco.value = false
  }
}

// ── Helpers ──
// ── Relatórios ──────────────────────────────────────────────
const TETO_BASE_ANUAL = computed(() => s.company.teto_mei_anual || 81000)
// No ano de abertura o teto é proporcional: teto ÷ 12 × meses de atividade (mês da abertura conta inteiro).
const mesesAtividadeNoAno = computed(() => {
  const ab = String(s.company.mei_data_abertura || '')
  const [y, m] = ab.split('-').map(Number)
  if (!y || !m) return 12
  const ano = Number(anoRelAnual.value)
  if (y === ano) return Math.max(1, 13 - m)
  return y > ano ? 0 : 12
})
const TETO_MEI_ANUAL = computed(() => TETO_BASE_ANUAL.value / 12 * mesesAtividadeNoAno.value)
const TETO_COM_TOLERANCIA = computed(() => TETO_MEI_ANUAL.value * 1.2)   // excesso de até 20%
const nomeContribuinte = 'MEI — Conta PagBank / Itaú'

const relTipo = ref('mensal')
const anoRelatorioAtual = computed(() => anoRelAnual.value)
const incluirRendasPessoais = ref(false)

// Meses disponíveis como { value, label } para o select do relatório mensal
const mesesRelatorio = computed(() =>
  mesesDisponiveis.value.map(m => ({ value: m, label: m }))
)

// Mês selecionado no relatório mensal (default: mês mais recente disponível)
const relMensalMesRef = ref('')
watch(mesesDisponiveis, (meses) => {
  if (meses.length && !relMensalMesRef.value) relMensalMesRef.value = meses[0]
}, { immediate: true })

// Dados do mês selecionado no relatório mensal
const dadosRelMensal = computed(() =>
  s.relatorioMensalMei.find(i => i.mes_ref === relMensalMesRef.value) || null
)

// Lançamentos do mês selecionado — MEI (entradas)
const lancMensalEntradas = computed(() => {
  if (!relMensalMesRef.value) return []
  return s.financeiro.filter(i =>
    i.mes_ref === relMensalMesRef.value &&
    i.natureza === 'entrada' &&
    i.categoria !== 'Rendimento Financeiro' &&
    i.valor > 0
  )
})

// Lançamentos do mês — entradas não-MEI (pessoal positivo, ex: Renda Pessoal)
const lancMensalNaoMei = computed(() => {
  if (!relMensalMesRef.value) return []
  return s.financeiro.filter(i =>
    i.mes_ref === relMensalMesRef.value &&
    i.natureza === 'pessoal' &&
    i.valor > 0
  )
})

// Lançamentos do mês — despesas (operacionais + pessoais se solicitado)
const lancMensalSaidasParaDoc = computed(() => {
  if (!relMensalMesRef.value) return []
  return s.financeiro.filter(i =>
    i.mes_ref === relMensalMesRef.value &&
    (i.natureza === 'operacional' || (incluirRendasPessoais.value && i.natureza === 'pessoal' && i.valor < 0))
  )
})

// Faturamento MEI do ano do relatório
const faturamentoAnoRel = computed(() =>
  s.relatorioMensalMei
    .filter(i => i.mes_ref.endsWith(`/${anoRelAnual.value}`))
    .reduce((a, i) => a + (i.receitas_mei || 0), 0)
)

const percentualTeto = computed(() =>
  TETO_MEI_ANUAL.value > 0 ? (faturamentoAnoRel.value / TETO_MEI_ANUAL.value) * 100 : 0
)

// Acumulado do ano até o mês selecionado no relatório mensal
const acumuladoAteMes = computed(() => {
  const [mesAtual, anoAtual] = (relMensalMesRef.value || '').split('/')
  if (!mesAtual || !anoAtual) return { receitas_mei: 0, saidas_operacionais: 0, saldo_operacional: 0, pct_teto: 0 }
  const mesesDoAno = s.relatorioMensalMei.filter(i => {
    const [m, a] = i.mes_ref.split('/')
    return a === anoAtual && Number(m) <= Number(mesAtual)
  })
  const receitas_mei = mesesDoAno.reduce((a, i) => a + (i.receitas_mei || 0), 0)
  const saidas_operacionais = mesesDoAno.reduce((a, i) => a + (i.saidas_operacionais || 0), 0)
  return {
    receitas_mei,
    saidas_operacionais,
    saldo_operacional: receitas_mei - saidas_operacionais,
    pct_teto: TETO_MEI_ANUAL.value > 0 ? (receitas_mei / TETO_MEI_ANUAL.value) * 100 : 0
  }
})

// ── Geração de documentos oficiais ──────────────────────────────
function gerarDocLivroCaixa() {
  gerarLivroCaixa({
    mes_ref:  relMensalMesRef.value,
    empresa:  s.company,
    entradas: lancMensalEntradas.value,
    naoMei:   lancMensalNaoMei.value,
    saidas:   lancMensalSaidasParaDoc.value,
    totais:   dadosRelMensal.value || {},
    acumulado: acumuladoAteMes.value,
    incluirNaoMei: incluirRendasPessoais.value
  })
}

function gerarDocDASN() {
  gerarDASNSIMEI({
    ano:      anoRelAnual.value,
    empresa:  s.company,
    meses:    relatorioAnualMeses.value,
    totais:   totalAnual.value,
    tetoAnual: TETO_MEI_ANUAL.value,
    pctTeto:  percentualTeto.value,
    incluirNaoMei: incluirRendasPessoais.value
  })
}

function retirSegura(mes) {
  // "Retirada segura" = o que o negócio gerou no mês (receitas − despesas operacionais) menos a reserva de giro.
  // Não é saldo do banco.
  const geradoNoMes = mes.total_gerado_retirada || 0
  const reservaGiro = s.reservaGiroEm(mes.mes_ref) || 0
  return geradoNoMes - reservaGiro
}
// O que já saiu do negócio para o bolso no mês (Pró-labore + transferências da conta PJ para contas próprias)
const retiradoMes = (mes) => Number(mes.retirado_negocio || 0)
const aindaDisponivel = (mes) => retirSegura(mes) - retiradoMes(mes)

// ── Meta de Retirada: accordions (detalhe do cálculo por mês + explicação) ──
// Fechados por padrão para manter o card enxuto; o usuário abre só o que
// quer conferir.
const detalhesAbertos = reactive({})
function toggleDetalhesMes(mesRef) {
  detalhesAbertos[mesRef] = !detalhesAbertos[mesRef]
}
const explicacaoAberta = ref(false)

// ── Resumo Mensal: accordion da composição de cada card de mês ──
// Mesmo princípio: o card mostra só o resultado (o que sobrou + 2
// indicadores-chave); a composição completa (receita/despesas linha a
// linha) fica escondida até o usuário pedir.
const detalhesMensalAbertos = reactive({})
function toggleDetalhesMensal(mesRef) {
  detalhesMensalAbertos[mesRef] = !detalhesMensalAbertos[mesRef]
}

onMounted(() => s.carregarFinanceiro())
</script>

<style scoped>
/* seletor de grupo agora usa .seg-control/.seg-btn globais (main.css) */
/* ── Painel excluir por banco ─────────────────────────────── */

/* Transição painel excluir */
.fade-slide-enter-active, .fade-slide-leave-active { transition: all .18s ease; }
.fade-slide-enter-from, .fade-slide-leave-to { opacity: 0; transform: translateY(-6px); }

/* ── Barra discreta de ações da lista ─── */
.lista-acoes-bar {
  display: flex;
  justify-content: flex-end;
  padding: 8px 16px 4px;
  background: transparent;
}
.btn-selecionar-sutil {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border: 1px solid var(--border);
  border-radius: var(--r-full);
  background: transparent;
  color: var(--muted);
  font-size: .72rem;
  font-weight: 700;
  transition: all var(--t);
}
.btn-selecionar-sutil:active {
  background: var(--cream-deep);
  color: var(--brown-mid);
  border-color: var(--brown-mid);
}
.btn-selecionar-sutil i { font-size: .7rem; }

/* ── Botão fechar seleção ─── */
.sel-fechar-btn { background: rgba(255,255,255,.14); border: none; color: rgba(255,255,255,.9); width: 44px; height: 44px; border-radius: var(--r-full); display: flex; align-items: center; justify-content: center; font-size: 1rem; flex-shrink: 0; margin-left: auto; }
.sel-fechar-btn:active { background: rgba(255,255,255,.22); }

/* ── Cabeçalho ─── */
.tab-hdr { 
  padding: 14px 16px 0; background: var(--surface); border-bottom: 1px solid var(--border); 
  flex-shrink: 0; 
  position: sticky; top: 0; z-index: var(--z-sticky);
}

.hdr-actions { display: flex; gap: 6px; }
.tab-financeiro .aba-btn { flex: 0 0 auto; padding-left: 12px; padding-right: 12px; }

/* ── Importadores ─── */
.importador-panel { margin: 0 -14px; border-top: 1px solid var(--border); background: var(--bg); }

.cat-list { display: flex; flex-direction: column; }
.cat-list-grupo { font-size: .8rem; font-weight: 800; color: var(--brown-mid); padding: 12px 16px 6px; background: var(--cream); border-bottom: .5px solid var(--border); }
.cat-list-item { display: flex; align-items: center; gap: 12px; min-height: 48px; padding: 10px 16px; border: none; border-bottom: .5px solid var(--border); background: var(--surface); color: var(--text); font-size: .95rem; font-weight: 600; text-align: left; width: 100%; transition: background var(--t); }
.cat-list-item:last-child { border-bottom: none; }
.cat-list-item:active { background: var(--gold-bg); }
.cat-list-item.active {
  background: var(--gold-bg);
  color: var(--brown-dark);
  border-left: 3px solid var(--brown);
  padding-left: 13px;
}
.cat-list-icon { width: 20px; text-align: center; color: var(--muted); font-size: .95rem; flex-shrink: 0; }
.cat-list-item.active .cat-list-icon { color: var(--brown-mid); }
.cat-list-item span { flex: 1; }
.cat-list-check { color: var(--brown); font-size: .9rem; }
.grupo { margin-bottom: 4px; }
.grupo-titulo { font-size: .72rem; font-weight: 800; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; margin-bottom: 8px; display: flex; align-items: center; gap: 6px; }
.grupo-natureza { padding: 2px 7px; border-radius: var(--r-full); font-size: .65rem; font-weight: 800; }
.nat-entrada { background: var(--green-bg); color: var(--green); }
.nat-operacional { background: var(--red-bg); color: var(--red); }
.nat-pessoal { background: var(--gold-bg); color: var(--orange); }
.filtro-select { padding: 7px 10px; border: 1px solid var(--border); border-radius: var(--r-md); background: var(--bg); color: var(--text); font-size: .82rem; appearance: none; }
.filtro-select.sm { width: auto; min-width: 80px; }
.nat-interna { background: var(--blue-bg); color: var(--blue); }
.check-icon { color: var(--brown) !important; font-size: .75rem !important; width: auto !important; }

/* ── Estilos Filtros Modernos Consolidados ── */
.lancamentos-sticky {
  position: sticky;
  top: 0;
  z-index: var(--z-sticky);
  background: var(--surface);
  box-shadow: 0 2px 8px rgba(61,31,7,.07);
}

.periodo-mini-nav { display: flex; align-items: center; gap: 8px; padding: 11px 16px; border-bottom: 1px solid var(--border); background: var(--surface); }
.periodo-inline { display: flex; align-items: center; gap: 2px; flex-shrink: 0; }
.pnav-mini-btn { width: 38px; height: 40px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--bg); font-size: .75rem; color: var(--brown-mid); flex-shrink: 0; }
.pnav-mini-centro { flex: 1; position: relative; height: 40px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--cream); display: flex; align-items: center; justify-content: center; min-width: 0; overflow: hidden; }
.pnav-mini-centro select { position: absolute; inset: 0; opacity: 0; width: 100%; cursor: pointer; }
.pnav-mini-centro span { font-size: .82rem; font-weight: 700; color: var(--brown-dark); }

/* ── Barra de filtros compacta (Movimentações): uma linha de chips + popover ── */
.filtros-bar { background: var(--surface); border-bottom: 1px solid var(--border); }
.fbar-row { display: flex; align-items: center; gap: 8px; padding: 10px 12px; }
.fbar-search-btn { flex-shrink: 0; width: 44px; height: 44px; border: 1px solid var(--border); border-radius: var(--r-md); background: var(--bg); color: var(--brown-mid); display: flex; align-items: center; justify-content: center; font-size: .95rem; transition: all var(--t); }
.fbar-search-btn.active { border-color: var(--brown); color: var(--brown); background: var(--gold-bg); }
.fbar-scroll { flex: 1; min-width: 0; display: flex; gap: 8px; overflow-x: auto; scrollbar-width: none; -webkit-overflow-scrolling: touch; }
.fbar-scroll::-webkit-scrollbar { display: none; }
.fbar-chip { flex-shrink: 0; display: flex; align-items: center; gap: 6px; height: 44px; padding: 0 12px; border: 1px solid var(--border); border-radius: var(--r-full); background: var(--bg); color: var(--brown-mid); font-size: .84rem; font-weight: 700; white-space: nowrap; transition: all var(--t); }
.fbar-chip-caret { font-size: .62rem; opacity: .7; }
.fbar-chip.active { border-color: var(--brown); color: var(--brown-dark); background: var(--gold-bg); }
.fbar-chip.open { border-color: var(--brown); box-shadow: 0 0 0 2px var(--gold-bg) inset; }
.fbar-limpar { flex-shrink: 0; display: flex; align-items: center; gap: 6px; height: 44px; padding: 0 10px; border: none; background: transparent; color: var(--red); font-weight: 800; font-size: .86rem; }
.fbar-limpar-badge { background: var(--red); color: #fff; font-size: .72rem; min-width: 20px; height: 20px; border-radius: 10px; padding: 0 5px; display: flex; align-items: center; justify-content: center; font-weight: 800; }

.filtro-popover { padding: 12px; border-top: 1px solid var(--border); background: var(--bg); touch-action: pan-y; }
.filtro-popover-scroll {
  padding: 0;
  max-height: min(48vh, 360px);
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior: contain;
}
.fbusca-wrap { position: relative; }
.fbusca-icon { position: absolute; left: 13px; top: 50%; transform: translateY(-50%); color: var(--muted); font-size: .95rem; }
.fbusca-input { width: 100%; min-height: 48px; padding: 10px 40px 10px 38px; border: 1.5px solid var(--border); border-radius: var(--r-md); background: var(--surface); font-size: 1rem; }
.fbusca-clear {
  position: absolute; right: 8px; top: 50%; transform: translateY(-50%);
  width: 22px; height: 22px; border: none; border-radius: 50%;
  background: var(--border2); color: var(--muted); font-size: .65rem;
  display: flex; align-items: center; justify-content: center;
}
.fchips { display: flex; gap: 8px; flex-wrap: wrap; }
.fchip { min-height: 44px; padding: 0 18px; border: 1px solid var(--border); border-radius: var(--r-full); background: var(--surface); color: var(--brown-mid); font-size: .9rem; font-weight: 700; transition: all var(--t); }
.fchip.active { background: var(--brown); color: #fff; border-color: var(--brown); }

.resumo-modern { display: flex; align-items: stretch; background: var(--surface); border-bottom: 1px solid var(--border); padding: 12px 8px; justify-content: space-between; }
.rm-item { display: flex; flex-direction: column; flex: 1; min-width: 0; align-items: center; gap: 3px; }
.rm-lbl { font-size: .78rem; color: var(--muted); font-weight: 700; }
.rm-val { font-family: var(--mono); font-size: 1rem; font-weight: 800; font-variant-numeric: tabular-nums; white-space: nowrap; }
.rm-sep { width: 1px; align-self: stretch; background: var(--border); margin: 2px 0; }

.fm-status-bar { display: flex; justify-content: center; align-items: center; padding: 8px 16px; background: var(--cream); border-top: 1px solid var(--border); }
.fm-count { font-size: .84rem; color: var(--brown-mid); font-weight: 700; }

/* Transições */
.fade-slide-enter-active, .fade-slide-leave-active { 
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
  max-height: 400px; 
  overflow: hidden; 
}
.fade-slide-enter-from, .fade-slide-leave-to { 
  opacity: 0; 
  max-height: 0; 
  transform: translateY(-10px); 
}

/* ── Aviso transferência interna ─── */
.trans-interna-hint { display: flex; align-items: center; gap: 8px; width: 100%; min-height: 44px; padding: 10px 16px; background: none; border: none; border-top: 1px solid var(--border); font-size: .84rem; font-weight: 700; color: var(--gold-dark); cursor: pointer; text-align: left; }
.trans-interna-hint i { font-size: .85rem; }

/* ── Barra de seleção em lote ─── */
.selecao-dica { font-size: .82rem; color: var(--muted); padding: 10px 16px 4px; display: flex; align-items: center; gap: 8px; }
.selecao-bar { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 6px 12px; background: var(--brown-dark); color: #fff; flex-shrink: 0; }
.sel-all-btn { background: none; border: none; min-height: 44px; padding: 0 6px; color: rgba(255,255,255,.92); font-size: .9rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.sel-all-btn i { font-size: 1.05rem; color: var(--gold-light); }
.sel-count { font-size: .88rem; font-weight: 800; color: var(--gold-light); }

/* ── Lista ─── */
.lancamentos-list { padding-top: 8px; padding-bottom: max(96px, calc(72px + env(safe-area-inset-bottom))); touch-action: pan-y; }
.lancamento-row { margin: 0 16px 10px; min-height: 64px; }

.row-operacional { border-left-color: var(--red); }
.row-pessoal { border-left-color: var(--purple); }
.row-entrada { border-left-color: var(--green); }
.row-interna { opacity: .65; background: var(--gold-bg); border-left-color: var(--gold); }
.row-interna:active { background: var(--gold-bg); }

.row-selected { background: var(--gold-bg) !important; }

/* Checkbox de seleção */
.row-check { width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.row-check i { font-size: 1.1rem; color: var(--muted); transition: color var(--t); }
.row-selected .row-check i { color: var(--brown); }

/* ── Barra flutuante de lote ─── */
.barra-lote {
  position: fixed;
  bottom: max(80px, calc(72px + env(safe-area-inset-bottom)));
  left: 50%;
  transform: translateX(-50%);
  width: calc(100% - 32px);
  max-width: 448px;
  background: var(--brown-dark);
  border-radius: var(--r-xl);
  padding: 12px 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  box-shadow: 0 8px 32px rgba(30,18,8,.35);
  z-index: var(--z-overlay);
}
.barra-lote-info { display: flex; align-items: baseline; gap: 4px; flex: 1; }
.barra-lote-info strong { color: var(--gold-light); font-size: 1rem; font-weight: 800; }
.barra-lote-info span  { color: rgba(255,255,255,.65); font-size: .78rem; }

.barra-btn { padding: 8px 14px; border: none; border-radius: var(--r-full); font-size: .82rem; font-weight: 700; display: flex; align-items: center; gap: 6px; transition: all var(--t); white-space: nowrap; }
.barra-btn.cancel  { background: rgba(255,255,255,.12); color: rgba(255,255,255,.8); }
.barra-btn.cancel:active  { background: rgba(255,255,255,.22); }
.barra-btn.primary { background: var(--gold); color: var(--brown-dark); }
.barra-btn.primary:active { background: var(--gold-light); }

/* Transição barra lote */
.barra-lote-enter-active, .barra-lote-leave-active { transition: all .22s var(--t-spring); }
.barra-lote-enter-from, .barra-lote-leave-to { opacity: 0; transform: translateX(-50%) translateY(16px) scale(.95); }
.row-banco-badge { width: 26px; height: 26px; border-radius: 6px; font-size: .65rem; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.row-banco-badge.pagbank { background: var(--gold-bg); color: var(--gold-dark); }
.row-banco-badge.itau    { background: var(--blue-bg); color: var(--blue); }
.row-banco-badge.bb      { background: var(--gold-bg); color: var(--blue); }
.row-left { flex: 1; min-width: 0; }
.row-title { font-size: .96rem; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.row-subtitle { font-size: .8rem; color: var(--muted); display: flex; align-items: center; gap: 6px; flex-wrap: wrap; margin-top: 3px; }

/* ── Empty ─── */
.empty-mini { text-align: center; color: var(--muted); padding: 32px 24px; font-size: .82rem; display: flex; flex-direction: column; align-items: center; gap: 8px; line-height: 1.5; }
.empty-mini i { font-size: 1.8rem; opacity: .2; }

/* ── Relatório ─── */
.relatorio-wrap { padding: 14px 16px max(96px, calc(72px + env(safe-area-inset-bottom))); display: flex; flex-direction: column; gap: 14px; }

/* Anual */

/* Gráfico */
.grafico-barras { display: flex; align-items: flex-end; gap: 6px; height: 80px; padding-bottom: 4px; overflow-x: auto; }
.barra-grupo { display: flex; flex-direction: column; align-items: center; gap: 2px; min-width: 36px; flex-shrink: 0; }
.barra-labels { display: flex; align-items: flex-end; gap: 2px; height: 64px; }
.barra { width: 14px; border-radius: 3px 3px 0 0; transition: height 0.4s ease; }
.barra.entrada { background: var(--green); }
.barra.saida   { background: var(--red); opacity: .75; }
.barra-mes { font-size: .6rem; color: var(--muted); font-weight: 600; white-space: nowrap; }

/* Tabela anual */

.renda-pessoal { background: var(--purple-bg); border-radius: 4px; padding-left: 4px; padding-right: 4px; }

/* ── Aba Relatórios ─────────────────────────────────────── */
.rel-tipo-nav { display: flex; gap: 8px; padding: 0; }
.rel-tipo-btn { flex: 1; min-height: 52px; padding: 8px 10px; border: 1.5px solid var(--border); border-radius: var(--r-lg); background: var(--surface); color: var(--brown-mid); font-size: .88rem; font-weight: 800; line-height: 1.25; text-align: center; display: flex; align-items: center; justify-content: center; gap: 8px; cursor: pointer; transition: all var(--t); }
.rel-tipo-btn.active {
  background: var(--brown);
  color: #fff;
  border-color: var(--brown);
}

/* ── Barra de teto ── */
.teto-card { border-left: 3px solid var(--brown); }
.teto-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 12px; gap: 8px; }
.teto-titulo { font-size: .88rem; font-weight: 800; color: var(--brown-dark); }
.teto-sub { font-size: 0.82rem; color: var(--muted); margin-top: 2px; }
.teto-valor-wrap { text-align: right; flex-shrink: 0; }
.teto-valor { font-family: var(--mono); font-size: 1.1rem; font-weight: 800; }
.teto-pct { font-size: 0.8rem; color: var(--muted); margin-top: 2px; }

.teto-barra-wrap { margin-bottom: 6px; }
.teto-barra-bg {
  position: relative;
  height: 12px;
  background: var(--cream-deep);
  border-radius: 99px;
  overflow: hidden;
}
.teto-barra-fill {
  height: 100%;
  border-radius: 99px;
  transition: width .6s ease;
}
.teto-barra-fill.ok      { background: var(--green); }
.teto-barra-fill.warning { background: var(--orange); }
.teto-barra-fill.danger  { background: var(--red); }
.teto-barra-mark { margin-top: 5px; text-align: right; padding-right: 2px; }
.teto-falta { font-size: 0.78rem; color: var(--muted); font-weight: 600; display: inline-block; }

.teto-alertas { margin-top: 4px; }
.teto-alerta {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 10px;
  border-radius: var(--r-md);
  font-size: 0.86rem;
  font-weight: 600;
}
.teto-alerta.alerta-warning { background: var(--gold-bg); color: var(--orange); }
.teto-alerta.alerta-danger  { background: var(--red-bg); color: var(--red); }
.teto-alerta i { flex-shrink: 0; margin-top: 1px; }

/* ── Livro Caixa ── */
.lc-cabecalho {
  background: var(--cream);
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  padding: 8px 10px;
  margin-bottom: 12px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.lc-cb-linha {
  display: flex;
  flex-direction: column;
  gap: 1px;
  font-size: 0.84rem;
}
.lc-cb-linha span { color: var(--muted); font-size: 0.78rem; font-weight: 800; text-transform: uppercase; letter-spacing: .4px; }
.lc-cb-linha strong { color: var(--text); font-size: 0.86rem; word-break: break-word; line-height: 1.3; }

.lc-section-label {
  font-size: 0.76rem;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: .6px;
  padding: 8px 10px;
  margin: 16px 0 8px;
  border: 1px solid var(--border);
  border-radius: var(--r-sm);
}
.lc-section-label.entrada { background: var(--green-bg); color: var(--green); }
.lc-section-label.saida   { background: var(--red-bg); color: var(--red); }
.lc-section-label.pessoal { background: var(--purple-bg); color: var(--purple); }
.lc-section-label:not(.entrada):not(.saida):not(.pessoal) { background: var(--cream); color: var(--brown-mid); }

.lc-tabela {
  margin-bottom: 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.lc-hdr { display: none; } /* hidden — using card layout instead */
.lc-row { flex-direction: column; align-items: stretch; gap: 4px; }
/* top line: badge + valor */
.lc-row .lc-col-cat  { order: 1; }
.lc-row .lc-col-val  { order: 1; }
.lc-row .lc-col-desc { order: 2; color: var(--text); font-size: .8rem; word-break: break-word; line-height: 1.35; }
.lc-row .lc-col-data { order: 3; color: var(--muted); font-size: 0.78rem; font-weight: 600; }
/* use flexbox row for first line via pseudo wrapper — handle in template instead */
.lc-col-top { display: flex; align-items: center; justify-content: space-between; gap: 6px; }
.lc-col-data { color: var(--muted); font-size: 0.78rem; font-weight: 600; }
.lc-col-desc { color: var(--text); word-break: break-word; line-height: 1.35; font-size: .8rem; }
.lc-col-cat  { }
.lc-col-val  { font-family: var(--mono); font-size: .86rem; font-weight: 700; flex-shrink: 0; }
.lc-badge {
  display: inline-block;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.78rem;
  font-weight: 700;
  white-space: nowrap;
}
.lc-entrada { background: var(--green-bg); color: var(--green); }
.lc-saida   { background: var(--red-bg); color: var(--red); }
.lc-pessoal { background: var(--purple-bg); color: var(--purple); }

.lc-vazio { font-size: 0.86rem; color: var(--muted); padding: 8px 0; }

.lc-total {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px;
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  background: var(--cream);
  font-size: .8rem;
  font-weight: 700;
}
.lc-total-label { color: var(--text); }
.lc-total strong { font-family: var(--mono); font-size: .88rem; }
.pessoal-total { border-top-color: var(--purple-bg); }

/* Resumo do mês */
.lc-resumo {
  margin-top: 14px;
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  overflow: hidden;
}
.lc-resumo-linha {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  font-size: .8rem;
  border-bottom: 1px solid var(--border);
}
.lc-resumo-linha:last-child { border-bottom: none; }
.lc-resumo-linha span { color: var(--muted); }
.lc-resumo-linha strong { font-family: var(--mono); font-size: .84rem; }
.lc-resumo-linha.destaque { background: var(--cream); font-weight: 700; }
.lc-resumo-linha.destaque span { color: var(--text); font-weight: 700; }
.lc-resumo-linha.sub { background: var(--bg); opacity: .8; }

/* Acumulado */
.lc-acumulado {
  margin-top: 14px;
  background: var(--gold-bg);
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  padding: 10px 12px;
}
.lc-acum-titulo {
  font-size: 0.82rem;
  font-weight: 800;
  color: var(--brown-mid);
  text-transform: uppercase;
  letter-spacing: .5px;
  margin-bottom: 10px;
}
.lc-acum-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.lc-acum-item {
  background: var(--surface);
  border-radius: var(--r-sm);
  padding: 8px 10px;
  border: 1px solid var(--border);
}
.lc-acum-item span { display: block; font-size: 0.78rem; color: var(--muted); font-weight: 700; text-transform: uppercase; letter-spacing: .3px; margin-bottom: 4px; }
.lc-acum-item strong { font-family: var(--mono); font-size: .88rem; font-weight: 800; }

/* Quadro anual */
.lc-quadro {
  margin-bottom: 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  overflow-x: auto;
}
.lc-q-linha {
  display: grid;
  grid-template-columns: 62px 1fr 1fr;
  gap: 8px;
  padding: 10px 12px;
  font-size: 0.84rem;
  border: 1px solid var(--border);
  border-left: 5px solid var(--brown-light);
  border-radius: var(--r-md);
  background: var(--surface);
  box-shadow: var(--shadow-sm);
  align-items: center;
}
.lc-q-linha.hdr {
  font-size: 0.76rem;
  font-weight: 800;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: .4px;
  border-left-color: transparent;
  box-shadow: none;
  background: transparent;
}
.lc-q-linha.total {
  font-weight: 700;
  border-color: var(--border);
  border-left-color: var(--gold);
  background: var(--cream);
}
.lc-q-mes { color: var(--text); font-weight: 600; }
.lc-q-linha span { font-family: var(--mono); }
.lc-q-linha span:first-child { font-family: var(--font); }

/* Resumo anual */
.lc-resumo-anual {
  border: 1px solid var(--border);
  border-radius: var(--r-md);
  overflow: hidden;
}
.lra-linha {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 9px 12px;
  font-size: .8rem;
  border-bottom: 1px solid var(--border);
}
.lra-linha span { color: var(--muted); }
.lra-linha strong { font-family: var(--mono); font-size: .86rem; }
.lra-linha.destaque { background: var(--cream); font-weight: 700; }
.lra-linha.destaque span { color: var(--text); font-weight: 700; }
.lra-linha.sub { background: var(--bg); opacity: .8; font-size: 0.84rem; }
.lra-verificacao {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  font-size: 0.84rem;
  font-weight: 700;
  background: var(--green-bg);
  color: var(--green);
  border-top: 1px solid var(--border);
}
.lra-verificacao i { font-size: .85rem; }

/* Nota rodapé */
.rel-nota {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  font-size: .72rem;
  color: var(--muted);
  line-height: 1.5;
  padding: 10px 4px 4px;
}
.rel-nota i { flex-shrink: 0; color: var(--brown-light); margin-top: 1px; }

/* ── Meta de Retirada (reorganizada: KPIs no topo, um número principal
   por card, detalhes do cálculo e explicação escondidos por padrão) ── */

/* Cabeçalho — duas métricas com o mesmo peso visual, empilhadas no
   celular estreito (padrão do app, ver .mei-grid) e lado a lado a
   partir de 420px. */
.mtr-kpis { display: flex; flex-direction: column; gap: 10px; }
@media (min-width: 420px) { .mtr-kpis { flex-direction: row; } }
.mtr-kpi { flex: 1; display: flex; align-items: flex-start; gap: 12px; padding: 16px; background: var(--surface); border-radius: var(--r-lg); border: 1px solid var(--border); box-shadow: var(--shadow-sm); }
.mtr-kpi-ico { width: 42px; height: 42px; flex-shrink: 0; border-radius: var(--r-md); background: var(--cream); color: var(--brown); display: flex; align-items: center; justify-content: center; font-size: 1.05rem; }
.mtr-kpi--giro .mtr-kpi-ico { background: var(--orange-bg); color: var(--orange); }
.mtr-kpi-txt { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.mtr-label { font-size: .8rem; font-weight: 700; color: var(--muted); }
.mtr-valor { font-size: 1.35rem; font-weight: 800; color: var(--brown-dark); font-family: var(--mono); line-height: 1.2; }
.mtr-sub { font-size: .78rem; color: var(--muted); line-height: 1.4; margin-top: 1px; }

.mtr-lista { display: flex; flex-direction: column; gap: 12px; }

.mtr-card { border: 1px solid var(--border); border-radius: var(--r-lg); padding: 16px; background: var(--surface); box-shadow: var(--shadow-sm); display: flex; flex-direction: column; gap: 14px; }

/* Mês + selo de status — dá pra escanear a lista inteira sem ler números */
.mtr-card-topo { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.mtr-card-mes { font-weight: 800; font-size: 1.08rem; color: var(--brown-dark); }
.mtr-badge { font-size: .76rem; font-weight: 800; padding: 5px 11px; border-radius: var(--r-full); white-space: nowrap; }
.mtr-badge--ok      { background: var(--green-bg);  color: var(--green); }
.mtr-badge--parcial { background: var(--orange-bg); color: var(--orange); }
.mtr-badge--baixo   { background: var(--red-bg);    color: var(--red); }

/* Número principal do card — o que a pessoa realmente veio ver */
.mtr-card-principal { display: flex; flex-direction: column; gap: 2px; }
.mtr-card-principal-lbl { font-size: .84rem; font-weight: 700; color: var(--muted); }
.mtr-card-retirada { font-size: 1.8rem; font-weight: 800; font-family: var(--mono); line-height: 1.15; font-variant-numeric: tabular-nums; }

.mtr-bar-row { display: flex; align-items: center; gap: 8px; }
.mtr-bar-bg { flex: 1; height: 10px; background: var(--border); border-radius: 5px; overflow: hidden; }
.mtr-bar-fill { height: 100%; border-radius: 5px; transition: width .6s ease; }
.mtr-bar-pct { font-size: .84rem; color: var(--brown-mid); font-weight: 800; flex-shrink: 0; min-width: 38px; text-align: right; }

.mtr-labor { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; font-size: .84rem; color: var(--muted); padding: 10px 12px; background: var(--bg); border-radius: var(--r-md); }
.mtr-labor i { color: var(--brown-light); }
.mtr-labor-sep { opacity: .4; }
.mtr-labor-meta { opacity: .75; }

/* Detalhes do cálculo — escondido por padrão, abre em lista vertical
   (evita o wrap quebrado que operadores soltos causavam em telas estreitas) */
.mtr-detalhes-toggle { width: 100%; min-height: 46px; display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 14px; border: 1px solid var(--border); border-radius: var(--r-sm); background: var(--cream); color: var(--brown-mid); font-size: .88rem; font-weight: 700; text-align: left; cursor: pointer; }
.mtr-detalhes-toggle span { display: flex; align-items: center; gap: 6px; }
.mtr-detalhes-toggle i:last-child { font-size: .62rem; }
.mtr-detalhes-toggle:active { background: var(--cream-deep); }

.mtr-equacao { display: flex; flex-direction: column; gap: 4px; padding: 6px 4px 0; }
.mtr-eq-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-height: 38px; font-size: .92rem; color: var(--brown); }
.mtr-eq-row--sub { color: var(--muted); }
.mtr-eq-row strong { font-family: var(--mono); font-weight: 800; font-size: .92rem; }
.mtr-eq-row--result { margin-top: 4px; padding-top: 10px; border-top: 1px solid var(--border2); font-weight: 800; color: var(--brown-dark); }
.mtr-eq-row--result strong { font-size: 1.02rem; }

/* Explicação do tempo de produção — accordion, some do caminho até que
   a pessoa peça por ele */
.mtr-explainer-toggle { width: 100%; min-height: 52px; margin-top: 4px; display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 12px 14px; border-radius: var(--r-lg); background: var(--blue-bg); border: 1px solid var(--blue-dim, #bfdbfe); color: var(--blue); font-size: .88rem; font-weight: 800; text-align: left; cursor: pointer; }
.mtr-explainer-toggle span { display: flex; align-items: center; gap: 8px; }
.mtr-explainer { margin-top: -6px; padding: 16px; border-radius: var(--r-lg); background: var(--blue-bg); border: 1px solid var(--blue-dim, #bfdbfe); display: flex; flex-direction: column; gap: 12px; }
.mtr-exp-item { display: flex; flex-direction: column; gap: 3px; }
.mtr-exp-item strong { font-size: .9rem; color: var(--brown-dark); }
.mtr-exp-item span { font-size: .84rem; color: var(--brown); line-height: 1.55; }
.mtr-exp-aviso { display: flex; gap: 8px; padding: 10px 12px; border-radius: var(--r-md); background: var(--gold-bg); color: var(--gold-dark); font-size: .82rem; line-height: 1.5; }
.mtr-exp-aviso i { flex-shrink: 0; margin-top: 1px; }

@media (min-width: 420px) {
  .mei-grid { display: grid; grid-template-columns: repeat(2, 1fr); }
}

/* ════════════════════════════════════════════════════════════
   FIXES SAMSUNG A22 — tela estreita (≤ 380px)
   ════════════════════════════════════════════════════════════ */

/* 2 ── Livro Caixa: layout mobile — descrição + valor na linha 1, data + tipo na linha 2 */
@media (max-width: 380px) {
  .lc-hdr { display: none; }
  .lc-row {
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    gap: 2px 0;
    padding: 9px 0;
  }
  .lc-col-desc {
    order: 0;
    flex: 1 1 calc(100% - 76px);
    min-width: 0;
    font-size: 0.86rem;
    font-weight: 600;
    color: var(--text);
    padding-right: 6px;
    word-break: break-word;
    line-height: 1.35;
  }
  .lc-col-val {
    order: 1;
    flex: 0 0 auto;
    min-width: 72px;
    font-size: 0.86rem;
    text-align: right;
    padding-top: 0;
  }
  .lc-col-data {
    order: 2;
    flex: 0 0 auto;
    font-size: 0.76rem;
    color: var(--muted);
    padding-top: 3px;
    margin-right: 8px;
  }
  .lc-col-cat {
    order: 3;
    flex: 0 0 auto;
    padding-top: 3px;
  }
}


/* 4 ── Quadros DASN (Receita + Despesas): 3 colunas, sem scroll */
.lc-quadro {
  width: 100%;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none;
}
.lc-quadro::-webkit-scrollbar { display: none; }

/* Botão gerar documento oficial */
.btn-gerar {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 7px 12px;
  background: var(--blue);
  color: #fff;
  border: none;
  border-radius: var(--r-sm);
  font-size: .75rem;
  font-weight: 700;
  cursor: pointer;
  white-space: nowrap;
  transition: background var(--t), transform var(--t);
  flex-shrink: 0;
}
.btn-gerar:active { background: var(--brown-dark); transform: scale(.96); }

.incluir-pessoal-toggle {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 0.72rem;
  color: var(--muted);
  cursor: pointer;
}

.report-config-box { background: var(--bg); border: 1px solid var(--border); border-radius: var(--r-lg); padding: 14px; margin-bottom: 16px; display: flex; flex-direction: column; gap: 12px; }
.report-config-grid { display: grid; grid-template-columns: 1fr; gap: 10px; align-items: end; }
.report-config-grid .fg { margin: 0; }
.incluir-pessoal-toggle-modern { display: flex; align-items: center; gap: 6px; font-size: .84rem; color: var(--muted); cursor: pointer; flex: 1; min-width: 0; }
.btn-gerar-large { width: 100%; min-height: 52px; padding: 10px; background: var(--blue); color: #fff; border: none; border-radius: var(--r-md); font-size: .95rem; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; cursor: pointer; transition: all var(--t); }
.btn-gerar-large:active { background: var(--brown-dark); transform: scale(0.98); }

/* ════════════════════════════════════════════════════════════
   @MEDIA PRINT — formatação para impressão
   ════════════════════════════════════════════════════════════ */
@media print {
  /* Esconder chrome do app */
  .hdr, .nav, .tab-hdr,
  .rel-tipo-nav,
  .teto-alertas, .ano-selector-inline,
  .btn-abrir-import { display: none !important; }

  /* Resetar container */
  body, html { height: auto !important; overflow: visible !important; font-size: 11pt; }
  .shell, .main, 
  .relatorio-wrap {
    padding: 0 !important;
    gap: 10pt !important;
  }

  /* Cards sem sombra, sem quebra interna */
  .sheet-card {
    box-shadow: none !important;
    border: 1px solid var(--border) !important;
    break-inside: avoid;
    margin-bottom: 8pt;
  }

  /* Tabelas: mostrar sem scroll */
  .lc-quadro, .tabela-anual {
    overflow: visible !important;
  }
  .lc-q-linha  { min-width: auto !important; }
  .ta-hdr, .ta-row { min-width: auto !important; }

  /* Livro Caixa: restaurar grid de 4 colunas no papel */
  .lc-hdr {
    display: grid !important;
    grid-template-columns: 56px 1fr 80px 64px !important;
  }
  .lc-row {
    display: grid !important;
    grid-template-columns: 56px 1fr 80px 64px !important;
    flex-wrap: unset !important;
  }
  .lc-col-data, .lc-col-desc, .lc-col-cat, .lc-col-val {
    order: unset !important;
    flex: unset !important;
    padding-top: 0 !important;
  }

  /* Barra de teto sem alertas visuais desnecessários */
  .teto-card { border-left: 2px solid var(--text) !important; }

  /* Garantir cores legíveis no papel */
  
  
  
}

/* ══════════════════════════════════════════════════════════════
   Financeiro › Mensal — visual novo (classes mn-*, só desta aba)
══════════════════════════════════════════════════════════════ */
.mn-pagina { gap: 20px; }
.mn-pagina .c-green, .mn-pagina .c-red, .mn-pagina .c-blue, .mn-pagina .c-purple { font-variant-numeric: tabular-nums; }

/* Período */
.mn-periodo { display: flex; flex-wrap: wrap; gap: 8px; align-items: flex-end; padding: 14px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); box-shadow: var(--shadow-sm); }
.mn-campo { display: flex; flex-direction: column; gap: 6px; min-width: 0; }
.mn-campo--ano { flex: 0 0 76px; }
.mn-campo--mes { flex: 1 1 200px; }
.mn-label { font-size: .78rem; font-weight: 700; color: var(--muted); }
.mn-select {
  width: 100%; height: 48px; padding: 0 22px 0 9px; font-family: var(--font); font-size: .9rem; font-weight: 700; color: var(--brown-dark);
  background-color: var(--cream); border: 1.5px solid var(--border); border-radius: var(--r-sm); cursor: pointer;
  -webkit-appearance: none; appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%238c7260' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
  background-repeat: no-repeat; background-position: right 7px center; background-size: 10px;
}
.mn-select:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: 1px; }
.mn-mes { display: flex; align-items: center; gap: 5px; }
.mn-mes .mn-select { flex: 1; min-width: 0; }
.mn-seta {
  width: 44px; height: 48px; flex-shrink: 0; display: flex; align-items: center; justify-content: center;
  color: var(--brown-mid); font-size: .9rem; background: var(--cream); border: 1.5px solid var(--border); border-radius: var(--r-sm); cursor: pointer;
}
.mn-seta:active:not(:disabled) { background: var(--cream-deep); }
.mn-seta:disabled { opacity: .35; cursor: default; }
.mn-seta:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: 1px; }

/* Blocos */
.mn-bloco { display: flex; flex-direction: column; gap: 10px; }
.mn-bloco-cab { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; padding: 0 2px; }
.mn-bloco-titulo { margin: 0; font-size: 1.02rem; font-weight: 800; color: var(--brown-dark); }
.mn-bloco-sub { font-size: .8rem; font-weight: 600; color: var(--muted); }
.mn-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); box-shadow: var(--shadow-sm); overflow: hidden; }
.mn-vazio { margin: 0; padding: 22px 16px; text-align: center; font-size: .86rem; line-height: 1.5; color: var(--muted); }

.mn-ponto { width: 10px; height: 10px; flex-shrink: 0; border-radius: 50%; background: var(--border2); }
.mn-ponto--verde { background: var(--green); }
.mn-ponto--vermelho { background: var(--red); }

/* Por banco */
.mn-banco { padding: 14px 16px; border-top: 1px solid var(--border); }
.mn-banco:first-child { border-top: none; }
.mn-banco-topo { display: flex; align-items: center; gap: 12px; }
.mn-tile { width: 40px; height: 40px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: var(--r-md); font-size: 1.05rem; }
.mn-tile--pagbank { background: var(--gold-bg); color: var(--gold-dark); }
.mn-tile--itau { background: var(--orange-bg); color: var(--orange); }
.mn-banco-nome { flex: 1; min-width: 0; font-size: .98rem; font-weight: 800; color: var(--brown-dark); }
.mn-banco-saldo { display: flex; flex-direction: column; align-items: flex-end; line-height: 1.2; }
.mn-banco-saldo strong { font-family: var(--mono); font-size: 1.12rem; font-weight: 800; }
.mn-mini-lbl { font-size: .72rem; font-weight: 700; color: var(--muted); }
.mn-banco-det { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 12px; }
.mn-banco-det > div { display: flex; flex-direction: column; gap: 2px; padding: 8px 10px; background: var(--bg); border-radius: var(--r-sm); }
.mn-banco-det span { font-size: .76rem; font-weight: 600; color: var(--muted); }
.mn-banco-det strong { font-family: var(--mono); font-size: .92rem; font-weight: 800; }

/* Card do mês */
.mn-mes-card { padding: 16px; display: flex; flex-direction: column; gap: 14px; }
.mn-mes-cab { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.mn-mes-nome { margin: 0; font-size: 1.1rem; font-weight: 800; color: var(--brown-dark); }
.mn-chip { padding: 4px 10px; border-radius: var(--r-full); background: var(--cream); color: var(--muted); font-size: .76rem; font-weight: 700; white-space: nowrap; }
.mn-destaque { display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 14px 12px; border-radius: var(--r-md); text-align: center; }
.mn-destaque--ok { background: var(--green-bg); color: var(--green); }
.mn-destaque--neg { background: var(--red-bg); color: var(--red); }
.mn-destaque-lbl { font-size: .84rem; font-weight: 700; }
.mn-destaque-valor { font-family: var(--mono); font-size: 1.75rem; font-weight: 800; line-height: 1.15; font-variant-numeric: tabular-nums; }

.mn-linhas { display: flex; flex-direction: column; }
.mn-linha { display: flex; align-items: center; gap: 10px; min-height: 44px; padding: 8px 2px; border-top: 1px solid var(--border); }
.mn-linhas .mn-linha:first-child { border-top: none; }
.mn-linha-lbl { flex: 1; min-width: 0; font-size: .9rem; font-weight: 600; color: var(--text); }
.mn-linha strong { font-family: var(--mono); font-size: .9rem; font-weight: 800; flex-shrink: 0; }

/* Composição (aberta sob demanda) */
.mn-toggle {
  display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; min-height: 46px; padding: 10px 12px;
  font-family: var(--font); font-size: .88rem; font-weight: 700; color: var(--brown-mid);
  background: var(--cream); border: 1px solid var(--border); border-radius: var(--r-sm); cursor: pointer;
}
.mn-toggle:active { background: var(--cream-deep); }
.mn-toggle:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: 1px; }
.mn-toggle-seta { font-size: .7rem; margin-left: 2px; }
.mn-detalhe { display: flex; flex-direction: column; gap: 12px; }
.mn-grupo { padding: 12px; background: var(--bg); border-radius: var(--r-md); }
.mn-grupo-titulo { margin-bottom: 4px; font-size: .78rem; font-weight: 800; color: var(--muted); }
.mn-linha--simples { min-height: 38px; padding: 6px 0; border-top: 1px solid rgba(0, 0, 0, .05); }
.mn-grupo-titulo + .mn-linha--simples { border-top: none; }
.mn-linha--total { margin-top: 4px; border-top: 1px solid var(--border2); }
.mn-linha--total .mn-linha-lbl { font-weight: 800; color: var(--brown-dark); }

/* Por categoria */
.mn-cat { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid var(--border); }
.mn-cat:first-child { border-top: none; }
.mn-cat-txt { flex: 1; min-width: 0; }
.mn-cat-nome { font-size: .94rem; font-weight: 700; color: var(--brown-dark); overflow-wrap: anywhere; }
.mn-cat-sub { margin-top: 2px; font-size: .78rem; color: var(--muted); }
.mn-cat-valor { flex-shrink: 0; font-family: var(--mono); font-size: .95rem; font-weight: 800; }
@media (prefers-reduced-motion: reduce) { .mn-seta, .mn-toggle { transition: none; } }

/* ── Movimentações: valor da linha e conta por extenso ── */
.lancamentos-list .row-right { font-family: var(--mono); font-size: 1rem; font-weight: 800; font-variant-numeric: tabular-nums; white-space: nowrap; }
.lancamentos-list .row-right.green { color: var(--green); }
.lancamentos-list .row-right.red { color: var(--red); }
.lancamentos-list .fl-dot { display: none; }
.lancamentos-list .fl-banco-sigla { display: none; }
html.is-desktop .lancamentos-list .fl-banco-nome { display: none; }
html.is-desktop .lancamentos-list .fl-banco-sigla { display: inline; }
.fchip:focus-visible, .fbar-chip:focus-visible, .fbar-search-btn:focus-visible, .cat-list-item:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: -3px; }

/* ══ Financeiro › Importar (classes im-*) ══ */
.im-pagina { gap: 20px; }
.im-cab { padding: 0 2px; }
.im-titulo { margin: 0; font-size: 1.3rem; font-weight: 800; line-height: 1.2; color: var(--brown-dark); }
.im-desc { margin: 4px 0 0; font-size: .88rem; line-height: 1.5; color: var(--muted); }
.im-bloco { display: flex; flex-direction: column; gap: 10px; }
.im-passo-cab { display: flex; align-items: center; gap: 10px; padding: 0 2px; }
.im-passo-cab h4 { margin: 0; font-size: 1.02rem; font-weight: 800; color: var(--brown-dark); }
.im-passo { width: 26px; height: 26px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 50%; background: var(--brown); color: #fff; font-size: .8rem; font-weight: 800; }
.im-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); box-shadow: var(--shadow-sm); overflow: hidden; }
.im-card--painel .importador-panel { margin: 0; border-top: none; background: var(--surface); }
.im-card--risco { border-color: var(--red-dim); background: #fffafa; }

.im-vazio { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 28px 20px; text-align: center; }
.im-vazio-icone { width: 52px; height: 52px; display: flex; align-items: center; justify-content: center; border-radius: 50%; background: var(--cream); color: var(--muted); font-size: 1.3rem; margin-bottom: 4px; }
.im-vazio strong { font-size: 1rem; color: var(--brown-dark); }
.im-vazio span { font-size: .86rem; line-height: 1.5; color: var(--muted); }

/* Escolha do banco */
.im-bancos { display: grid; grid-template-columns: repeat(auto-fit, minmax(96px, 1fr)); gap: 8px; }
.im-banco {
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; min-height: 76px; padding: 10px 8px;
  background: var(--surface); border: 1.5px solid var(--border); border-radius: var(--r-lg); color: var(--brown-mid); cursor: pointer; transition: all var(--t);
}
.im-banco i { font-size: 1.25rem; margin-bottom: 2px; }
.im-banco strong { font-size: .95rem; font-weight: 800; color: var(--brown-dark); }
.im-banco span { font-size: .76rem; font-weight: 600; color: var(--muted); }
.im-banco.active { background: var(--brown); border-color: var(--brown); color: #fff; box-shadow: var(--shadow-sm); }
.im-banco.active strong, .im-banco.active span { color: #fff; }
.im-banco:focus-visible, .im-admin-toggle:focus-visible, .im-excluir-btn:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: -3px; }

/* Excluir extratos */
.im-admin-toggle { display: flex; align-items: center; gap: 12px; width: 100%; min-height: 64px; padding: 12px 16px; background: none; border: none; text-align: left; cursor: pointer; }
.im-admin-icone { width: 40px; height: 40px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: var(--r-md); background: var(--red-bg); color: var(--red); }
.im-admin-txt { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.im-admin-txt strong { font-size: .95rem; font-weight: 800; color: var(--red); }
.im-admin-txt small { font-size: .8rem; color: var(--muted); }
.im-admin-seta { font-size: .75rem; color: var(--muted); }
.im-excluir { display: flex; flex-direction: column; gap: 8px; padding: 4px 16px 16px; border-top: 1px solid var(--red-dim); }
.im-excluir-aviso { margin: 8px 0 4px; font-size: .82rem; line-height: 1.5; color: var(--muted); }
.im-excluir-aviso i { color: var(--red); margin-right: 4px; }
.im-excluir-btn { display: flex; align-items: center; gap: 10px; min-height: 52px; padding: 10px 14px; background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-md); cursor: pointer; text-align: left; }
.im-excluir-btn:active { background: var(--red-bg); }
.im-excluir-nome { flex: 1; font-size: .92rem; font-weight: 700; color: var(--brown-dark); }
.im-excluir-qtd { font-size: .8rem; color: var(--muted); font-weight: 600; }
.im-excluir-btn i { font-size: .7rem; color: var(--muted); }
.im-excluir-btn--todos { border-color: var(--red-dim); background: var(--red-bg); }
.im-excluir-btn--todos .im-excluir-nome, .im-excluir-btn--todos .im-excluir-qtd { color: var(--red); }

/* ══ Financeiro › Retirada e mão de obra (mo-*) ══ */
.mo-pagina { gap: 0; }
/* A barra de progresso usava var(--accent), que não existe: sem isso a barra aparecia vazia quando a meta não era atingida */
.mtr-bar-row { --accent: var(--orange); }
.mo-corpo { display: flex; flex-direction: column; gap: 16px; }
.mo-cab { padding: 0 2px; }
.mo-titulo { margin: 0; font-size: 1.3rem; font-weight: 800; line-height: 1.2; color: var(--brown-dark); }
.mo-desc { margin: 4px 0 0; font-size: .88rem; line-height: 1.5; color: var(--muted); }
.mo-vazio { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 28px 20px; text-align: center; background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); }
.mo-vazio i { font-size: 1.6rem; color: var(--muted); margin-bottom: 4px; }
.mo-vazio strong { font-size: 1rem; color: var(--brown-dark); }
.mo-vazio span { font-size: .86rem; line-height: 1.5; color: var(--muted); }
.mtr-detalhes-toggle:focus-visible, .mtr-explainer-toggle:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: 1px; }

/* ══ Financeiro › Anual (classes an-*) ══ */
.an-pagina { gap: 20px; }
.an-cab { padding: 0 2px; }
.an-titulo { margin: 0; font-size: 1.3rem; font-weight: 800; line-height: 1.2; color: var(--brown-dark); }
.an-desc { margin: 4px 0 0; font-size: .88rem; line-height: 1.5; color: var(--muted); }
.an-anos { display: flex; gap: 8px; flex-wrap: wrap; }
.an-ano { min-width: 76px; min-height: 46px; padding: 0 20px; border: 1.5px solid var(--border); border-radius: var(--r-full); background: var(--surface); color: var(--brown-mid); font-size: .95rem; font-weight: 800; cursor: pointer; transition: all var(--t); }
.an-ano.active { background: var(--brown); border-color: var(--brown); color: #fff; }
.an-ano:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: 2px; }
.an-hero { display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 20px 16px; border-radius: var(--r-lg); text-align: center; }
.an-hero--ok { background: var(--green-bg); color: var(--green); border: 1px solid var(--green-dim); }
.an-hero--neg { background: var(--red-bg); color: var(--red); border: 1px solid var(--red-dim); }
.an-hero-lbl { font-size: .9rem; font-weight: 700; }
.an-hero-valor { font-family: var(--mono); font-size: 2rem; font-weight: 800; line-height: 1.15; font-variant-numeric: tabular-nums; }
.an-hero-sub { font-size: .8rem; font-weight: 600; opacity: .85; }
.an-bloco { display: flex; flex-direction: column; gap: 10px; }
.an-bloco-cab { padding: 0 2px; }
.an-bloco-titulo { margin: 0; font-size: 1.02rem; font-weight: 800; color: var(--brown-dark); }
.an-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-lg); box-shadow: var(--shadow-sm); overflow: hidden; }
.an-card--pad { padding: 16px; }
.an-linha { display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-top: 1px solid var(--border); }
.an-linha:first-child { border-top: none; }
.an-ponto { width: 10px; height: 10px; flex-shrink: 0; border-radius: 50%; background: var(--border2); }
.an-ponto--verde { background: var(--green); }
.an-ponto--vermelho { background: var(--red); }
.an-ponto--roxo { background: var(--purple); }
.an-linha-txt { flex: 1; min-width: 0; }
.an-linha-nome { font-size: .95rem; font-weight: 700; color: var(--brown-dark); }
.an-linha-sub { margin-top: 2px; font-size: .8rem; line-height: 1.4; color: var(--muted); }
.an-linha-valor { flex-shrink: 0; font-family: var(--mono); font-size: .98rem; font-weight: 800; font-variant-numeric: tabular-nums; }

/* Gráfico: reaproveita as classes do script (barra-*), só maior e mais legível */
.an-legenda { display: flex; gap: 16px; flex-wrap: wrap; margin-bottom: 12px; font-size: .82rem; font-weight: 700; color: var(--muted); }
.an-leg { display: inline-flex; align-items: center; gap: 6px; }
.an-leg i { width: 12px; height: 12px; border-radius: 3px; }
.an-leg--verde i { background: var(--green); }
.an-leg--vermelho i { background: var(--red); opacity: .75; }
.an-grafico.grafico-barras { height: 132px; gap: 8px; padding-bottom: 4px; align-items: flex-end; }
.an-grafico .barra-grupo { min-width: 44px; gap: 6px; }
.an-grafico .barra-labels { height: 96px; gap: 3px; }
.an-grafico .barra { width: 18px; border-radius: 4px 4px 0 0; transform: scaleY(1.55); transform-origin: bottom; }
.an-grafico .barra-mes { font-size: .76rem; font-weight: 700; color: var(--brown-mid); }

/* Tabela mês a mês */
.an-tabela { display: flex; flex-direction: column; }
.an-th, .an-tr { display: grid; grid-template-columns: 64px 1fr 1fr; gap: 8px; align-items: center; padding: 0 16px; }
.an-th { min-height: 40px; background: var(--cream); font-size: .8rem; font-weight: 800; color: var(--muted); }
.an-th span:not(:first-child), .an-tr span:not(:first-child) { text-align: right; }
.an-tr { min-height: 48px; border-top: 1px solid var(--border); }
.an-tr span { font-family: var(--mono); font-size: .88rem; font-weight: 700; font-variant-numeric: tabular-nums; }
.an-tr .an-td-mes { font-family: var(--font); font-size: .88rem; font-weight: 800; color: var(--brown-dark); }

/* ══ Financeiro › Relatórios (rl-*) ══ */
.rl-pagina { gap: 16px; }
.rl-cab { padding: 0 2px; }
.rl-titulo { margin: 0; font-size: 1.3rem; font-weight: 800; line-height: 1.2; color: var(--brown-dark); }
.rl-desc { margin: 4px 0 0; font-size: .88rem; line-height: 1.5; color: var(--muted); }
.report-config-grid .input { min-height: 48px; font-size: 1rem; }
.rl-switch-linha { display: flex; align-items: center; justify-content: space-between; gap: 12px; min-height: 48px; padding: 0 14px; background: var(--surface); border: 1.5px solid var(--border); border-radius: var(--r-sm); font-size: .92rem; font-weight: 700; color: var(--brown-dark); cursor: pointer; }
.rl-switch { -webkit-appearance: none; appearance: none; position: relative; flex-shrink: 0; margin: 0; width: 50px; height: 30px; border-radius: var(--r-full); background: var(--border2); cursor: pointer; transition: background var(--t); }
.rl-switch::after { content: ''; position: absolute; top: 3px; left: 3px; width: 24px; height: 24px; border-radius: 50%; background: #fff; box-shadow: 0 1px 3px rgba(0, 0, 0, .3); transition: transform var(--t); }
.rl-switch:checked { background: var(--green); }
.rl-switch:checked::after { transform: translateX(20px); }
.rl-switch:focus-visible, .rel-tipo-btn:focus-visible, .btn-gerar-large:focus-visible { outline: 3px solid rgba(122, 69, 32, .4); outline-offset: 2px; }
@media (min-width: 560px) { .report-config-grid { grid-template-columns: 1fr 1fr; } }
@media print { .rl-cab { display: none !important; } }

/* Relatórios: valores em reais nunca quebram em duas linhas; o rótulo é que quebra */
.lc-total, .lc-resumo-linha, .lra-linha { gap: 10px; }
.lc-total > span:first-child, .lc-resumo-linha > span:first-child, .lra-linha > span:first-child { flex: 1; min-width: 0; }
.lc-total strong, .lc-resumo-linha strong, .lra-linha strong, .lc-acum-item strong { white-space: nowrap; flex-shrink: 0; }
.lc-q-linha { grid-template-columns: 56px 1fr 1fr; gap: 6px; padding: 10px; }
.lc-q-linha span { font-size: .8rem; white-space: nowrap; }
.lc-q-linha span:not(:first-child) { text-align: right; }
.lc-q-linha span:first-child { white-space: normal; }
.lc-q-linha.hdr span { font-size: .72rem; }
.lc-q-linha .lc-q-mes { font-size: .8rem; }

/* Avisos e retirada já feita */
.fin-aviso { display: flex; gap: 10px; align-items: flex-start; margin: 10px 0; padding: 11px 13px; border-radius: var(--r-md); background: var(--orange-bg, #fff4e5); color: var(--orange, #b45309); font-size: 13px; font-weight: 600; line-height: 1.4; }
.fin-aviso i { margin-top: 2px; }
.fin-aviso--mini { font-size: 12px; padding: 9px 11px; }
.mtr-retirado { display: flex; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin: 10px 0 2px; padding: 9px 12px; border-radius: var(--r-sm); background: var(--cream); font-size: 12.5px; font-weight: 600; color: var(--muted); }
.mtr-retirado strong { margin-left: 4px; font-family: var(--mono); }
.lc-estorno { display: flex; justify-content: space-between; gap: 10px; padding: 10px 14px; font-size: 13px; font-weight: 600; color: var(--muted); }
</style>